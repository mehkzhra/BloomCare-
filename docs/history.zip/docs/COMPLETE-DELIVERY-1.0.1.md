# BloomCare 1.0.1 delivery notes

## Scope

- Separate privacy pages and controls for patient, doctor, administrator and signed-out visitors; matched sidebar copy and Urdu translations.
- Cohesive navy interface with one accent per role, stronger hierarchy and consistent risk colours.
- Patient-confirmed erroneous-assessment removal with a reason, retained audit, owner-only permissions and idempotent retries.
- Removal propagated to active history, doctor cases, family views, exports, dashboards, timeline, passport and analytics. New PE, review, export, care-guide and alert requests are blocked for removed results.
- Existing clinician notes and reviews are retained and labelled. Notes may be amended under the original appointment permissions; removed results cannot acquire new clinical activity. Pending follow-up proposals are withdrawn.
- Accurate direct/STUN/TURN video diagnostics, shared server/setup validation, safe camera/microphone preview, and clearer call-permission errors. The doctor’s camera opens before starting a new call session.
- Admin Connected services page with missing setting names, copyable Windows commands, manual PDF-sharing guidance and separate live-check requirements. New `check-services.cmd` and guided video configuration.

## Database and installation

`0011_assessment_removal` adds two nullable columns: `removed_at` and `removal_reason`. Existing assessments, PE results, clinical notes, reviews and accounts are preserved. The migration is forward-only; rollback requires a verified backup and its matching application version. The updater backs up first and uses an isolated PostgreSQL database for checks before touching the application schema.

Extract this combined ZIP into the existing project and run `scripts\update-final.cmd`. Never overwrite your local `backend\.env` or model trust with examples. These private files are excluded from this ZIP.

## PE limitation and current behavior

The original imported forest supports systolic BP **90–130 mmHg**, diastolic BP **20–90 mmHg**, age **18–38** and pregnancy duration **14–40 weeks**, plus narrow ranges for additional measurements. Those are model data limits, not clinical normal ranges. For example, a real systolic value of 150 exceeds the original forest’s coverage. It stays 150 in the saved record and no PE model category is generated.

The updated screen states this explicitly, lists affected values, avoids incorrectly blaming missing measurements and offers a doctor review. A pending-input stage is labelled “Measurements needed”; unsupported inputs and an unavailable model have their own states. A doctor can still review observations and save a clinical decision.

This release does not widen training ranges, clip readings, generate synthetic diagnoses or promote an unqualified candidate. The actual v1.0.0 retraining reports remain included. Improving PE coverage requires suitable, licensed, verified outcome data with consistent units and a separately evaluated model. Neither model is clinically validated.

## Service setup and real verification

The status endpoint reads configuration without making provider requests or sending messages. It never returns secret values, TURN credentials or approved phone numbers to the admin page. Participant video-readiness responses expose only mode, label and explanatory copy.

- **Video:** an empty valid ICE list means direct mode. STUN and TURN are identified from parsed URLs; invalid configuration is shown as invalid. Direct mode is not a guarantee that different networks can connect. Use localhost on the same computer or HTTPS on other devices, allow media permissions, use an active accepted appointment, and test doctor plus patient devices. Restrictive networks may require TURN credentials from your provider.
- **WhatsApp:** manual PDF sharing is separate from automatic Twilio alerts. Automatic alerts require valid server configuration, an approved sender, opted-in allowlisted contacts and the relevant sandbox/customer-service-window/template conditions. For sandbox free-text alerts, leave Content SID blank and send within 24 hours of the recipient’s join message. Custom templates need a registered sender. Restart after configuration. Submitted/queued is not delivered; refresh provider delivery status.
- **Groq:** a saved key is configuration evidence. Verify access, model availability and quota using a consented patient question. Do not share the key in chat.

Primary implementation references: [WebRTC connectivity](https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API/Connectivity), [media capture requirements](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia), [Twilio WhatsApp Sandbox](https://www.twilio.com/docs/whatsapp/sandbox).

## Necessary handover checks

1. Complete the updater with no errors; start the two servers and Ctrl+F5.
2. Sign in separately as patient, doctor and administrator; verify role-specific navigation and privacy. Use separate browser profiles for the live video call.
3. Create one disposable assessment, delete it with a reason, and verify the active count falls while the deletion log remains available. Enter a corrected record for a replacement.
4. Review a supported PE example and a genuinely unsupported saved reading. Explain the model limitation accurately in the presentation.
5. Test a real two-device consultation and a consented provider action if those integrations are part of the demonstration. Keep a manual report-sharing path available.
6. Before public hosting, verify HTTPS, backups/restore, deployment load and organisational privacy/retention requirements.

See `VERIFICATION-1.0.1.json` for the exact checks executed here. Windows/PostgreSQL execution, browser visuals, camera devices, actual provider delivery and deployed load cannot be inferred from isolated Linux tests.
