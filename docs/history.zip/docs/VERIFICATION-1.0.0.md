# BloomCare v1.0.0 verification

Executed 16 October 2026 in the Linux workspace. The Windows host, real provider
accounts and deployment destination were not accessed.

| Executed check | Result |
| --- | --- |
| Backend regression/API suite | **205 passed, 1 skipped** in 49.66 seconds. The skip is a PostgreSQL-specific lock case under the isolated SQLite test configuration. |
| Frontend component/flow suite | **108 passed, 0 failed**, including all three new role workspaces, actual totals, approval privacy, review links, errors/retries, administration tabs/confirmation, Urdu and PE field details. |
| ML contract/comparison tests | **11 passed**; dataset integrity, promotion non-regression and independent portable-forest replay included. |
| Python and frontend lint | Ruff and ESLint passed. |
| Frontend build | Passed; lazy feature chunks for administration, care and extended modules. Main entry about 361.43 kB, shared chunk 140.44 kB; CSS 67.03 kB before gzip. No size-warning threshold increase. |
| Maternal retraining | 85 configuration evaluations, grouped training-only CV, three selected family candidates and replayed historical comparison. No candidate passed all promotion checks; active registration unchanged. |
| Legacy PE retraining | Actual new 400-tree fit, exact duplicates removed, 72/18 grouped partition with zero identical-group overlap; inactive evidence exported. |
| Schema/migration | Existing populated v0009 -> v0010 preservation/Alembic/foreign-key test remains in the passing suite; no new schema migration in v1.0.0. |
| PDF | Actual local jsPDF/font code generated 3-page English, 4-page Urdu-content and 4-page unsupported-value reports. PE values/bounds and Arabic shaping inspected after rendering. QA identities/results were synthetic and are not supplied as real patient reports. |
| Bounded authenticated benchmark | 100 synthetic patients, 10 concurrent clients, 300 requests; **300 HTTP 200 responses and 300 ownership checks passed**. Median 122.82 ms, p95 233.68 ms, maximum 458.57 ms in this run. |

The benchmark used in-process FastAPI TestClient, disposable SQLite and already
issued test sessions. It excludes real network, model inference, Groq/Twilio,
video, production PostgreSQL and login-hashing load. It does not establish a
100-simultaneous-user or hosted response-time guarantee. Full metadata is in
PERFORMANCE-1.0.0.json. Its source command refuses an existing output path and
creates its own disposable database rather than using the application's database.

Backend tests verify workspace ownership, SQL totals beyond page length,
unapproved-doctor privacy, doctor grant cancellation, correct implicit-PENDING
review counts, approval filtering, exact unsupported values and protected/missing
training evidence. Existing real-model, appointment, upload, consent, family,
communication, review, migration and audit regressions remain included.

Representatives of primary text, secondary text, buttons and risk/status badge
colours were contrast checked and adjusted. This is not a full WCAG or screen-
reader certification. Browser visual QA was unavailable in the workspace; target
desktop/mobile rendering and actual device interactions still need review.

One existing Starlette/httpx deprecation warning remains in the backend test
environment. Poppler may emit an Adobe-Identity-H font-collection notice; rendered
PDF text and pagination were inspected rather than relying on extracted text.

## Destination checks not executed here

- Run update-final.cmd through success on Windows: it backs up the local database
  and runs the full migration/API suite against temporary PostgreSQL first.
- Check the redesigned pages, keyboard navigation and Urdu/RTL in target browsers.
- Test actual Groq responses, opted-in Twilio delivery, device PDF sharing and
  two-device WebRTC/TURN over the intended network/HTTPS deployment.
- Verify hosted security/operations, a backup-restore drill and the real deployed
  load target. Optional deployment templates are not claimed as deployed.
- Obtain and evaluate suitable clinical outcome data before claiming wider PE
  coverage or medical validation. The current maternal accuracy remains 71.11%.

Training evidence is an executed engineering record, not a clinical certificate.
