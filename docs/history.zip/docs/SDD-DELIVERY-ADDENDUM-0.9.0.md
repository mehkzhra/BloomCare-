# SDD delivery addendum - BloomCare v0.9.0

Date: 16 October 2026. This describes the actual delivered architecture and
supersedes conflicting implementation details in the supplied older design PDF.
The original PDF remains unchanged. Requirement references use the original SRS
FR-01 through FR-32; the older SDD's numbering diverges after FR-05.

## Implemented architecture

The browser runs a React/Vite application with role-based routes, English/Urdu
layout, grouped patient tools and a top-level video entry. Requests use the
same-origin `/api` path and an authenticated HTTP-only cookie. FastAPI performs
authority and validation independently of the UI. SQLAlchemy/Alembic target
PostgreSQL; isolated automated tests also use SQLite. UUID string identifiers and
normalized tables replace the older two-entity/integer-ID sketches.

| Layer | Current modules and responsibilities |
| --- | --- |
| UI input/history | `health-form.jsx`, `assessments.jsx`, `pe-screening.jsx`, `search-ui.jsx`; actual-value entry, conversion, staged results, filters. |
| UI clinical workflows | `clinical-ui.jsx`; saved care guide, reviews/history, proposal/acceptance, reschedule, amendment, PDF/share and alert actions. |
| UI monitoring | `analytics-ui.jsx`; native SVG category/trend charts, authorized doctor workspace, pregnancy milestones, admin oversight. |
| PDF | `pdf-export.js`, pinned local jsPDF and embedded DejaVu/Noto Naskh fonts. No CDN runtime requirement. |
| Core APIs | Auth/roles, assessment, appointments, patient care, reports/messages/notifications, family, assistant, video and admin routers. |
| Delivery APIs | `delivery_api.py` delegates to care-plan, clinical-review, follow-up and WhatsApp services. |
| Inference | Verified registered maternal model plus pinned legacy PE JSON forest; original fitted node weights feed actual TreeSHAP. |
| Persistence | 29 SQLAlchemy application tables plus Alembic revision tracking; database constraints, row locks/CAS checks and immutable history records. |
| External services | Explicitly consented Groq text generation, opt-in Twilio alert delivery, and peer-to-peer WebRTC media using configured ICE. |

Native SVG charts are a deliberate implementation variation from the old Recharts
proposal. jsPDF and Twilio are now actual integrations, rather than descriptions
of browser printing/manual report sharing alone. The application loads no old PE
pickle during an API request. SQLite remains an isolated-test option, not the
Windows application database in this delivery.

## Assessment and care-plan flow

```mermaid
flowchart TD
  A["Save actual observations and known clinical inputs"] --> B["Run verified maternal classifier"]
  B --> C{"PE category or warning gate?"}
  C -->|No| D["Save maternal result and PE not indicated"]
  C -->|Yes| E{"Inputs complete and supported?"}
  E -->|Yes| F["Save original PE forest output and TreeSHAP"]
  E -->|No| G["Keep missing or unsupported state for review"]
```

Record request UUIDs are unique per patient. Repeating the same body reuses the
record; changing a previously used request ID returns 409. Model failure after a
record save returns the saved record ID. Missing clinical values are not guessed.
Maternal results remain immutable; effective PE state is derived consistently
from saved input/child results for history, passport and family summaries.

After a separate consent action, the care-plan service hashes the exact saved
context plus language. A READY version may be reused; provider generation has an
in-progress lease, rate limit and failure cooldown. Name/email are excluded from
the provider context. Provider failure stores the failed attempt without a fake
answer. A plan whose context no longer matches is returned as stale so the UI/PDF
can request an updated guide.

## Clinical authority and changes

Doctor access requires an active approved doctor, an accepted unexpired care
episode, an active patient and that assessment's selected record. This check
applies before review, explanation, report-data and note operations. Patient
revocation removes subsequent access and case-analytics inclusion.

Clinical review has a monotonically increasing version. The UI submits the
version it saw; a conflicting update returns 409. Each accepted change also saves
an immutable review-event snapshot with actor and appointment and creates a
patient notification. A missing review is displayed as PENDING.

An author can append a note amendment under an authorized appointment. The new
note references its predecessor; original text remains stored. A predecessor has
at most one direct successor. A public note cannot acquire a hidden correction.
Patient PDF data contains only patient-visible notes linked to that assessment.

```mermaid
flowchart TD
  A["Doctor proposes follow-up"] --> B["Patient reviews time and consent"]
  B -->|Accept| C["Check slot and create PENDING appointment"]
  B -->|Decline or expiry| D["Close proposal without a booking"]
  C --> E["Doctor confirms or rejects request"]
  E --> F["Patient may request a revised time"]
  F --> C
```

Proposals have a doctor request UUID and expire after at most 72 hours or their
scheduled start. Acceptance is patient scoped and atomically links the requested
appointment. Rescheduling uses the appointment's last-update timestamp, approved
doctor and slot checks. It resets PENDING, ends record access and active calls,
removes report-share rows and notifies the doctor. The new appointment still needs
doctor confirmation; reports must be explicitly shared again.

## Persistence model

There are 29 application tables. Clinical content is stored in its specific
entity, rather than embedded appointment/note arrays on a user row.

| Group | Tables |
| --- | --- |
| Identity and audit (5) | users, patient_profiles, doctor_profiles, account_events, access_audit |
| Observations and models (5) | health_records, model_versions, assessments, pe_screenings, assessment_care_plans |
| Appointment lifecycle (4) | appointments, appointment_records, appointment_events, follow_up_proposals |
| Clinician documentation (3) | doctor_notes, clinical_reviews, clinical_review_events |
| Patient daily records (2) | symptom_entries, medication_entries |
| Files and grants (2) | medical_reports, report_shares |
| Communication (2) | care_messages, notifications |
| Family and reminders (2) | family_grants, medication_reminders |
| Assistant (1) | assistant_turns |
| Video (2) | consultations, consultation_signals |
| External alert tracking (1) | whatsapp_alerts |

Migration `0010_delivery_workflows` adds five workflow tables, clinical snapshots,
record request IDs, PE explanations, note amendment/assessment links and
assessment-linked notifications. It preserves old data and updates the PE parent
constraint to permit warning-triggered LOW maternal assessments. The migration is
forward-only; rollback uses a verified database backup with matching source.

## Principal added API contracts

All paths below have the `/api` prefix. Existing auth, care and communication
routes remain present. UUID ownership is checked; knowing an identifier does not
grant access.

| Method/path | Authority and purpose |
| --- | --- |
| POST /patients/me/complete-assessment | Patient; idempotent save plus actual staged inference. |
| POST /patients/me/assessments/{id}/care-plan | Owner; explicit Groq consent/language, persisted context version. |
| POST /patients/me/assessments/{id}/pe/explanation | Owner; add real pinned-model explanation only if saved scores match. |
| PUT /doctors/me/appointments/{appt}/assessments/{id}/review | Authorized approved doctor; expected version and review instructions. |
| GET .../assessments/{id}/reviews | Owner or authorized appointment doctor; immutable event history. |
| POST /doctors/me/appointments/{appt}/notes/{id}/amend | Authorized original author; append correction without deleting original. |
| POST /doctors/me/appointments/{appt}/follow-ups | Authorized doctor; proposal, assessment and request UUID. |
| GET /patients/me/follow-ups | Patient's own proposals. |
| POST /patients/me/follow-ups/{id}/accept or /decline | Patient; acceptance requires sharing consent and slot checks. |
| PATCH /patients/me/appointments/{id}/reschedule | Patient; expected last-update timestamp and sharing confirmation. |
| GET /doctors/me/cases and /doctors/me/analytics | Approved doctor; active selected records only. |
| GET /admin/clinical-reviews | Admin; persisted review oversight/search. |
| GET .../assessments/{id}/report-data | Owner or authorized appointment doctor; safe report projection. |
| GET /patients/me/whatsapp/status | Patient; capability flags, no secrets. |
| POST /patients/me/assessments/{id}/alerts | Owner; consent, approved E.164 contact, request UUID and rate limit. |
| GET /patients/me/alerts/{id} | Owner; authenticated provider status retrieval, no resend. |
| GET /patients/me/pregnancy-tracker | Patient; saved-date-derived progress and planning milestones. |

## External effects, failures and information boundaries

Twilio sends use a fixed HTTPS endpoint, authentication kept on the server and
bounded timeouts. A durable SUBMITTING reservation is committed before the
outbound call. Retrying its request UUID returns the existing result. Provider
errors/timeouts are represented as FAILED or UNCERTAIN, not success; no automatic
second send follows an unknown outcome. Provider message IDs are validated and
cannot change during refresh. QUEUED/SENT and DELIVERED/READ remain distinct.

Only two dynamic category/stage values are sent through an optional approved
template. The full PDF is prepared through a separately authorized read and
shared only after the patient chooses the external app/recipient. Native sharing
or downloading a PDF does not prove it was delivered through WhatsApp.

Core saved timestamps are serialized in UTC. Frontend date-only filters represent
the user's local day and become timezone-aware UTC interval bounds. Database
transactions protect mutations; PostgreSQL-only lock behaviour is tested by the
Windows disposable-database runner rather than claimed from SQLite.

Secrets, original private model artifacts, patient uploads and database backups
are excluded from the distribution archive. The offline PE explanation exporter
is a maintainer tool that validates the original pickle digest before loading it;
the hosted application reads checked JSON only.

## Verification boundary

See [VERIFICATION-0.9.0.md](VERIFICATION-0.9.0.md) for actual results. Provider API
effects are mocked in automated tests; live account approval/delivery, native
sharing, device media/TURN, hosted TLS, disaster recovery and deployed load remain
destination checks. Original model quality, coverage and unit limitations remain
unchanged by the new design.
