# BloomCare foundation fix 0.1.1

## Results from your uploaded Windows log

- Backend: 28 tests passed.
- PostgreSQL: migration and schema comparison passed; 28 workflow tests passed on the second run; the temporary PostgreSQL database was removed.
- Frontend: lint passed, five tests passed, and the production build succeeded.
- An exit-time Windows error still occurred during the SQLite run because a pooled database connection kept the temporary file open.
- The readiness command was run in Command Prompt, where `Invoke-RestMethod` is not a command.

These results confirm the implemented foundation checks. They do not establish that future AI or appointment features are complete.

## Apply this patch

Extract this ZIP directly into `D:\Desktop\BloomCare`, replacing these two matching files:

1. `backend\tests\conftest.py`
2. `scripts\check.ps1`

The third file is this instruction document. No installation, new dependency, environment change, or database migration is required for this patch.

## What changed

The test suite now has a session-scoped finalizer. Once test clients and database sessions have closed, it disposes the SQLAlchemy connection pool and then explicitly removes the temporary test directory. This closes idle connections before Windows tries to delete the SQLite file. Cleanup failures now appear during pytest teardown instead of being deferred to an interpreter-exit callback.

The Windows check script calls `npm.cmd` explicitly for frontend lint, tests, and build.

Reference for disposing SQLAlchemy connection pools: https://docs.sqlalchemy.org/en/20/core/connections.html#engine-disposal

## Rerun in your current Command Prompt

Keep Docker and the backend/frontend running. Run these commands one at a time:

```bat
cd /d D:\Desktop\BloomCare
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\check.ps1
.\backend\.venv\Scripts\python.exe .\scripts\test_postgres.py
curl.exe --fail http://127.0.0.1:8000/api/health/ready
```

Expected:

- 28 backend tests pass; no `WinError 32` temporary-file cleanup traceback.
- Five frontend tests pass; lint/build succeed; final message `All checks passed.`
- PostgreSQL migration/workflow checks pass and the temporary test database is removed.
- Readiness returns `{"status":"ready"}`. If curl cannot connect, start the backend as below and retry.

If using PowerShell instead, the first command is `Set-Location D:\Desktop\BloomCare`. The remaining commands work in either shell.

## Start services if necessary

Backend, in a separate Command Prompt:

```bat
cd /d D:\Desktop\BloomCare\backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

Frontend, in another Command Prompt:

```bat
cd /d D:\Desktop\BloomCare
npm.cmd --prefix .\frontend run dev
```

Open http://127.0.0.1:5173. Check that a saved profile and health record survive a reload, and that another patient's account has its own empty history.

## Verification of the patch

The patch is checked with the existing backend workflow suite and an additional live-process cleanup check: after pytest finishes, its temporary database directory must already be absent and its connection pool must contain no checked-out or idle connections. This build environment is Linux; the actual Windows file-lock regression must be confirmed by rerunning the supplied command on your machine.

The existing Starlette `httpx` deprecation warning is separate from the file-lock error and does not fail the tests. This patch does not change dependencies to address that warning.
