# SRS/SDD release addendum - v1.0.0

16 October 2026. The original supplied SRS/SDD PDFs remain unchanged. The v0.9.0
addenda retain the full FR-01 through FR-32 mapping; this file records the new
implementation and acceptance evidence. Requirement IDs follow the SRS, avoiding
the older SDD's numbering mismatch after FR-05.

| Requirement area | v1.0.0 delta |
| --- | --- |
| FR-01/02/19 identity/access | Three role-specific workspaces with independent protected summary endpoints. Unapproved doctors receive no patient data. Existing ownership/grant policies remain authoritative. |
| FR-03/05 assessment and PE | Exact unsupported field/value/bounds in the assessment and exported report. Actual records remain immutable; unsupported inference remains unavailable. |
| FR-04/06/27 model output/explanation | Existing registered model and actual explanations retained; weaker retraining candidates do not silently replace them. Candidate model exports are inactive, non-executable JSON evidence. |
| FR-09/10/11/13/14 clinical workflows | Overview links prioritize selected records, next appointment, review queue and clinician follow-up. Accepted appointments only open clinical review when access is currently available. |
| FR-15/16 report/sharing | PDF includes coverage details. Share-sheet handoff and external delivery are explicitly different; automatic alert setup has a usable manual-PDF alternative. |
| FR-17 analytics | Real SQL totals rather than list lengths; correct review counts include assessments without a first review. Semantic risk/status colours are stable across database result order. |
| FR-18 search/filter | Pending/approved doctor filtering and usable links into prefiltered account management. |
| FR-29 language/accessibility | New patient/doctor/admin strings in Urdu, keyboard-operated administration tabs, focus restoration and reduced-motion styling. |
| FR-31 evaluation | Protected, lazy-loaded training evidence shows executed configurations, old comparison limits, failed promotion checks and actual legacy PE data-quality findings. |
| FR-32 operations | Same schema head 0010; updated cumulative Windows checks, training commands, local synthetic benchmark, URL-log suppression and preserved private runtime state. |

## Current architecture

React uses a shared shell with role colour tokens and dedicated workspaces. The
main route tree uses Suspense and lazy feature imports with an error boundary.
Workspace requests validate response shape and expose explicit retry states.
Administration opens only the selected management tab and model evidence on demand.

`workspace_api.py` returns bounded, authorized dashboard projections with actual
database totals. Doctor analytics are restricted to active selected-record grants;
patient projections use only the signed-in account. `training_api.py` projects
fixed release evidence for administrators and does not execute model training in
an HTTP request or expose candidate tree payloads.

The persistence model remains the 29 normalized application tables from v0.9.0.
No new table or reset is needed. New PE coverage metadata is a derived response
field, not a replacement for saved observations or historical model output.

`ml/train_comparison.py` and `ml/retrain_legacy_pe.py` provide reproducible offline
training, grouped evaluation, inactive evidence exports and non-regression checks.
Existing model trust and application activation are retained. Model quality cannot
be raised by relabelling records, shifting the comparison partition or claiming an
independent evaluation that was not run.

## Quality acceptance

Executed results are in VERIFICATION-1.0.0.md and PERFORMANCE-1.0.0.json. The
functional/code changes and internal tests do not by themselves satisfy clinical
validation, an 85% accuracy target, independent PE outcome validity, hosted uptime,
production 100-user concurrency, or target-device media acceptance. Those material
limits remain explicit in the delivery.

Existing modules are retained. This release improves their presentation,
information flow, access handling and review evidence; its new interface does not
change the meaning of the original clinical source data.
