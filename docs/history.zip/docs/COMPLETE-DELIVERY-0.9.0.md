# BloomCare v0.9.0 combined Windows handover

Release date: 16 October 2026. Target: the existing local Windows installation
using the Compose PostgreSQL service on port 5433, Python virtual environment,
Node.js 24 or later, and the already registered maternal model.

## Install this single combined update

1. Stop the backend and frontend using Ctrl+C in their own terminals. Keep Docker
   Desktop running. Copying code does not perform a database migration.
2. Extract the ZIP contents directly into `D:\Desktop\BloomCare`. Replace the
   included source files; do not create a second nested BloomCare folder.
3. Keep root `.env`, `backend\.env`, `backend\model-trust.json`, the virtual
   environment, database volumes, uploaded files and trained maternal artifacts.
   These private/runtime files are excluded from this ZIP.
4. Run this command in Windows Command Prompt:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

The combined command checks dependencies and lint, verifies the PE model, starts
the existing local database if needed, saves a timestamped PostgreSQL backup under
`backups`, runs frontend lint/tests/build, and runs all migrations/API tests in a
separate temporary PostgreSQL database. Only after these checks pass does it
upgrade the application database and run the delivery prerequisite check.

The script stops at the first failed check. Read that error before starting the
servers. A failed frontend or temporary-database check does not advance the
application schema. Do not use a database reset to get past an error.

Successful output: `BloomCare v0.9.0 complete update passed.` Start the servers in
two separate CMD windows:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-backend.cmd
```

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-frontend.cmd
```

Open http://127.0.0.1:5173 and press Ctrl+F5. Patient and doctor accounts register
and sign in from the website. An admin approves doctor accounts. Existing account
passwords remain valid; the update does not create or publish passwords.

This is an update to the working installation, not a blank-machine installer.
If frontend dependencies were removed, run `npm.cmd --prefix frontend ci` before
the update. Initial secrets/model activation are intentionally not regenerated.

## What this release includes

| Area | Delivered behaviour |
| --- | --- |
| Interface | Colour accents, compact patient navigation, top video action, professional information pages and collapsed assistant history. |
| Assessment entry | One form for actual observations and known antenatal values; mg/dL and Fahrenheit defaults; selectable units with conversion; faint start/end model ranges inside inputs. Unknown answers stay unknown. |
| Staged screening | Real maternal inference followed by PE when the category is MEDIUM/HIGH or recorded warning indicators apply. Complete supported inputs run PE automatically; missing inputs request completion. |
| Explanations | Actual TreeSHAP for the maternal classifier and the pinned original PE forest, with additive checks. Model explanations describe model behaviour. |
| Saved care guide | Optional consented Groq generation, stored against the assessment and its screening context. Older plans are marked when the PE stage changes. No provider response is fabricated on failure. |
| Clinician workflow | Review status, urgent follow-up instructions, version/conflict checks, review history, author-owned note amendments preserving original notes, and patient-visible notes in reports. |
| Follow-ups | Doctor proposals, patient acceptance and sharing consent, expiry, slot conflict checks, and rescheduling that requires renewed doctor confirmation. |
| PDF/report sharing | Paginated assessment PDF with measurements, screening results, explanations, care guide, review and patient-visible notes. Local English and Urdu fonts. Explicit sharing consent and device share/download fallback. |
| WhatsApp alerts | Optional Twilio category alert to approved contacts with consent, durable request IDs, send limits, and provider status refresh. Queued and uncertain states remain distinct from delivered. |
| Monitoring | Scoped doctor case search/charts, admin search and oversight, pregnancy milestones based on saved dates, and actual observation trends. |
| Existing modules | Appointments, video signaling, messages, uploads, selected-report sharing, medications/reminders, symptoms, notifications, family grants, passport, Urdu/RTL, account activity and access audit. |

## Integration configuration

The already configured Groq key is reused for both the separate assistant and
optional assessment care guides. If configuration is needed:

```cmd
.\scripts\configure-integrations.cmd groq
```

Enter keys only at the hidden local prompt. Restart the backend afterward. A care
guide sends assessment measurements and screening results with consent; account
name and email are excluded. User-written assistant questions have their own
consent and optional selected-record context.

PDF sharing does not need Twilio. On supported devices, choose WhatsApp from the
share sheet. Otherwise the report downloads and WhatsApp opens; the patient
attaches the downloaded PDF and chooses the recipient there. BloomCare does not
claim that opening WhatsApp means a report was sent.

To enable the separate server-originated category alerts:

```cmd
.\scripts\configure-whatsapp.cmd
```

The script requests the Twilio account SID/auth token, approved WhatsApp sender,
opted-in recipient numbers in E.164 format and an optional approved Content SID.
It preserves unrelated settings and sends no message during configuration.
Restart the backend. Disable alerts with:

```cmd
.\scripts\configure-whatsapp.cmd --disable
```

The approved template must accept exactly the values used by this release:
`{{1}}` is the maternal category; `{{2}}` is the PE category or stage. No raw
measurements, patient name, email, report attachment or private clinician note is
included in this category alert. These brief alerts should be discussed with the
patient; the full assessment PDF is a separate sharing action.

Outside WhatsApp's 24-hour customer-service window, use an approved template via
ContentSid/ContentVariables. Free-form alerts require an active window. Sandbox
recipients must join that sandbox. Provider account access, sender/template
approval, recipient opt-in and credits are destination configuration, not supplied
credentials. See the official [Twilio template guide](https://www.twilio.com/docs/whatsapp/tutorial/send-whatsapp-notification-messages-templates)
and [key concepts](https://www.twilio.com/docs/whatsapp/key-concepts).

After sending, check the displayed provider status. A saved request ID prevents
duplicate submission of the same alert. If status is UNCERTAIN, check the provider
console before deliberately preparing another alert. Refreshing status never
sends the message again.

For video outside one machine/network, configure the existing WebRTC ICE settings
and a suitable TURN service, serve over HTTPS, and test actual camera/microphone
permissions on both devices. Signaling tests alone do not verify media traversal.

## Data and migration

Head revision is `0010_delivery_workflows`. Existing maternal outputs are not
rewritten. New records retain clinical inputs, request IDs, saved care plans,
review versions/events, follow-up proposals and alert status. The migration test
upgrades a populated v0009 database, checks preserved historical rows and foreign
keys, and verifies metadata with Alembic.

Migration 0010 is forward-only. Reversion requires a verified backup and matching
source version. The update saves a database dump before migration; it does not
prove a successful restore, and does not back up uploaded files, secrets or model
artifacts. Retain those separately. Restore is explicitly guarded by
`--confirm-restore`; do not run restore against the live working installation as
a routine update step. Test recovery in a separate destination.

## Handover checks on your Windows installation

1. Run the combined update through its success message; record the PostgreSQL test
   result and the new schema revision. One PostgreSQL lock test is skipped in the
   Linux SQLite verification environment and runs in this script's PostgreSQL suite.
2. Register a patient and doctor through the website, approve the doctor as admin,
   and verify both role choices and password visibility controls.
3. Enter actual supported observations in mg/dL/Fahrenheit, switch units, and run
   the complete assessment. Test missing PE inputs and an unsupported PE reading;
   an unsupported value must remain saved without an invented PE result.
4. With consent, generate a live Groq care guide; check it remains saved after
   refresh and that provider errors leave the assessment intact.
5. Share a selected assessment in an accepted appointment. Save a review, mark an
   urgent follow-up, amend a note, and confirm the patient notification/history.
6. Propose and accept a follow-up; reschedule an appointment; verify the revised
   slot needs confirmation and old report grants/calls have closed.
7. Download English/Urdu PDFs, open one on the target device, and complete a
   patient-authorized WhatsApp file share. If Twilio is enabled, verify a real
   opted-in alert and provider delivery status separately.
8. Test video with both roles on the intended devices, and exercise family grant
   acceptance/revocation, notifications, medications/reminders and admin filters.

The software verification results are in [VERIFICATION-0.9.0.md](VERIFICATION-0.9.0.md).
Live provider delivery, native-device sharing, production HTTPS/TURN, backup
restore and target-load performance were not executed in this workspace.

## Model boundaries that remain

The original PE model accepts systolic BP only within its documented 90-130 mmHg
coverage. A warning at 140 mmHg still triggers the PE workflow, but inference
correctly reports OUTSIDE_COVERAGE and requests clinical review. Never lower the
actual value to make the model run. HB units are not documented by the original
source and remain labelled accordingly.

The independently trained maternal model's recorded held-out accuracy is 71.11%,
with MEDIUM recall 33.33%. The legacy PE test split has substantial overlap with
training data. These do not establish clinical validity or satisfy a promised
accuracy threshold. Model evidence remains available for administrative review;
polished interface wording does not change that evidence.

No modules are removed or frozen by this release. External configuration,
deployment validation and new independently validated model data remain separate
handover work; they cannot be replaced by claiming tests that were not run.
