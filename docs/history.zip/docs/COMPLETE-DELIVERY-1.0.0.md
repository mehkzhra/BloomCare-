# BloomCare v1.0.0 Windows handover

Release date: 16 October 2026. This is a cumulative update for the working Windows
installation, not an instruction to reset its database or rerun initial setup.
It includes the earlier appointment, assessment, PE, care-plan, upload, message,
reminder, family, passport, assistant, video and administration modules.

## Install

1. Stop the backend and frontend in their terminals. Keep Docker Desktop running.
2. Extract the ZIP directly into `D:\Desktop\BloomCare`, replacing included files.
   Keep your `.env` files, virtual environment, database volumes, uploads,
   `backend\model-trust.json` and existing trained maternal artifacts. Those private
   and runtime files are excluded from the ZIP.
3. Run in Windows Command Prompt:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

The command checks dependencies, lint, ML contract tests, PE integrity and the
frontend. It saves a PostgreSQL backup, tests migrations/API workflows in a
disposable local PostgreSQL database, checks the existing application schema and
verifies installed dashboard assets and training evidence. It stops on failure.
The database head remains `0010_delivery_workflows`; no reset or new table migration
is required for these dashboard projections.

Successful output: `BloomCare v1.0.0 complete update passed.` Then run each startup
command in its own CMD window:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-backend.cmd
```

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-frontend.cmd
```

Open http://127.0.0.1:5173 and press Ctrl+F5. If frontend dependencies were removed,
run `npm.cmd --prefix frontend ci` before the updater. There are no new npm or
Python dependencies in this release; the existing pinned ML requirements are used.

## What changed

| Area | Current behaviour |
| --- | --- |
| Shared interface | Slim white navigation, clearer typography, role colour accents, compact panels, responsive layouts, visible focus, reduced-motion support and Urdu labels. Video stays in the header. |
| Patient overview | Real database totals, latest observations, date-derived pregnancy progress, latest assessment and next action, clinician follow-up, next appointment, assistant and approved care team. Unknown observations remain blank. |
| Doctor overview | Approval state, request/consultation totals, active shared-patient count, review queue, consultation list and scoped category/review charts. Clinical links require current record access. |
| Admin overview | Account and approval tasks, urgent reviews, correct unreviewed-assessment counts, service configuration, activity and lazy-loaded model evidence. Configured does not mean live provider delivery was tested. |
| Account management | People, appointments and activity in separate lazy-loaded tabs. Pending/approved doctor filters, preserved search links, keyboard tab navigation and confirmation before access removal. |
| PE coverage | Exact unsupported fields, recorded values and model bounds are shown in the assessment and PDF. Actual readings remain unchanged. Model bounds are not normal clinical ranges. |
| Charts | Risk/status colours follow their meaning rather than the order returned by the database. HIGH is not assigned the LOW colour. |
| Reliability | Dashboard payload validation, retry states, lazy feature loading and a recovery message for a failed view. Record/proposal/provider idempotency from prior releases remains. |
| Privacy | Provided startup/deployment commands suppress URL access logs that could contain search text. The application retains its protected route-template audit. Review infrastructure logging before hosting. |
| Training | Executed grouped comparisons, non-regression checks, portable inactive evidence artifacts and reproducible training commands. No measured regression replaces the registered model. |

## Integration setup

The existing Groq key is reused. If needed, configure it locally and restart the
backend:

```cmd
.\scripts\configure-integrations.cmd groq
```

Manual PDF sharing does not require Twilio: prepare the report, consent, choose
the external app/recipient and send there. BloomCare does not claim external
delivery from a share-sheet handoff.

Automatic category alerts need an approved Twilio sender/contact setup:

```cmd
.\scripts\configure-whatsapp.cmd
```

The existing v0.9.0 guide documents the two template variables and provider session
requirements. Configuration does not send a test message. Patient alert requests
remain explicit, consented and idempotent. For video outside the local network,
configure ICE/TURN and test both actual devices over HTTPS:

```cmd
.\scripts\configure-integrations.cmd webrtc
```

The service panel reports configuration flags only. It never labels a configured
provider as proven online or delivered without its corresponding evidence.

## Training outcome

Training was executed, not just described. The selected Random Forest, Extra Trees
and Gradient Boosting candidates did not pass all accuracy/macro-F1/MEDIUM/HIGH
recall checks against the current model. The current maternal model is retained.
The measured comparison and actual inactive forest exports are included under
`ml\training_reports`. Admin -> Model evaluation & evidence displays the summary.

The legacy PE data shrink from 203 to 90 unique rows after exact deduplication.
Their source has no systolic values above 130 mmHg, and the HB unit/confirmed PE
outcome definition remain undocumented. Retraining cannot supply missing clinical
coverage. An out-of-coverage reading still requests clinician review and is saved.

See [RETRAINING-1.0.0.md](RETRAINING-1.0.0.md) for exact results and reproducibility.
These software changes do not establish clinical validity or an achieved accuracy
target.

## Final checks on the destination

Follow [RECRUITER-WALKTHROUGH-1.0.0.md](RECRUITER-WALKTHROUGH-1.0.0.md) to exercise all
three roles. Confirm the updater's PostgreSQL result, then check the new pages in
your target browsers, including mobile/Urdu, real Groq care guides, optional opted-in
WhatsApp delivery, PDF sharing and two-device video.

The executed checks and their limits are in [VERIFICATION-1.0.0.md](VERIFICATION-1.0.0.md).
The local benchmark used synthetic users and disposable SQLite; it is not hosted
PostgreSQL or 100 simultaneous production users. Browser visual QA, real provider
delivery, deployed TLS/TURN, a restore drill and independent clinical validation
still require the destination environment. Deployment templates have not been
deployed by this update.

Database backups do not include uploads, secrets or trained artifacts. Retain those
separately. Migration 0010 remains forward-only; restore only a verified backup
with matching source, and test restoration separately from the working system.
