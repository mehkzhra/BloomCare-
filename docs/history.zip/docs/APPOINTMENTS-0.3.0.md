# BloomCare appointment and review checkpoint v0.3.0

This update extends only your new independent BloomCare project. It contains
no source, data, model, configuration, or account from the old 17-module project.
The research maternal model and its PE gate keep their existing behavior.
The separate PE model and clinical validation remain unfinished.

## Apply in Command Prompt

1. Stop the backend and frontend terminals with Ctrl+C.
2. Keep Docker Desktop running.
3. Extract BloomCare-Appointments-Update-v0.3.0.zip directly into
   D:\Desktop\BloomCare, replacing the included source files.
4. Open that folder in VS Code and run:

    cd /d D:\Desktop\BloomCare
    .\scripts\update-appointments.cmd

The script stops on the first failure. It checks dependencies and Python lint,
runs migrations and the complete API suite against a uniquely named local
PostgreSQL test database, then runs frontend lint, tests, and production build.
It finally upgrades your development database to 0003_appointments_review and
checks that the schema matches the models. The temporary test database is
removed afterward. Your development database is never dropped by this script.

The migration adds appointments, selected-record links, transition events,
and clinician notes. It preserves accounts, profiles, observations, assessments,
and model provenance. No new dependencies, model retraining, configuration
reset, or research activation change is required. The earlier session fix is
included. Do not rerun setup.py or delete your virtual environment.

Expected final message:

    Appointment update passed. Restart the backend and frontend.

## Create test doctor accounts if needed

Skip these commands for doctors that already exist. The trusted local CLI
creates approved staff accounts; public registration remains patient-only.
These are demo accounts, not evidence of professional registration.

    .\scripts\create-doctor.cmd --email doctor1@example.com --name "Demo Doctor One" --registration-number DEMO-001 --specialty Obstetrics
    .\scripts\create-doctor.cmd --email doctor2@example.com --name "Demo Doctor Two" --registration-number DEMO-002 --specialty Obstetrics

Each command asks for a password and confirmation without displaying it.
Use 12–128 characters. Enter passwords at the prompt, never in command arguments.
The account email and doctor registration number must be unique.

## Start

First Command Prompt terminal:

    cd /d D:\Desktop\BloomCare
    .\scripts\start-backend.cmd

Second terminal:

    cd /d D:\Desktop\BloomCare
    .\scripts\start-frontend.cmd

Third terminal:

    curl.exe --fail http://127.0.0.1:8000/api/health/ready

Open http://127.0.0.1:5173 consistently. API documentation is at
http://127.0.0.1:8000/docs; the backend root URL does not serve the frontend.
Readiness also checks appointment tables so missing migrations report
database_not_ready instead of a misleading ready response.

## Test the complete workflow

1. Sign in as a patient. Save a health observation and, if supported, run an
   experimental assessment. An observation can be shared even if the model
   rejects it or research assessment is disabled.
2. Open Appointments. Select Demo Doctor One, choose a future half-hour start,
   provide a reason, select the records to share, and check the consent box.
   Submit the request. It should show PENDING and remain after a page reload.
3. Use a separate browser profile or another browser for doctor testing.
   Sharing one browser cookie between two tabs signs both tabs into the same
   account; two tabs alone do not create separate patient and doctor sessions.
4. Sign in as Demo Doctor One. Open Appointments and accept the request.
   Review shared records. Only selected records and their stored assessments
   appear, together with the consented patient profile.
5. Add a patient-visible note, then a private note with the sharing box cleared.
   Reload to confirm they are saved. The patient sees only the visible note in
   Appointments → View clinician notes.
6. Sign in as Demo Doctor Two. The unrelated request should not be listed.
   Copying its review URL must fail without exposing patient data.
7. Cancel the appointment as the patient, or complete it as Doctor One.
   Refresh the doctor's review page: record access and new note writing must
   be denied. Previously authored notes remain in the doctor's own history;
   patient-visible notes remain in the patient's history.
8. Request the released slot again to confirm cancellation frees it. A second
   active request for the same doctor or patient at that time returns 409.

For model demonstrations use the already supplied public-source test examples
in docs/PUBLIC-DEMO-0.2.1.json. Keep real measured values unchanged.

## Time, scope, and transitions

- Requests are 30-minute slots within the next 90 days. The interface uses
  the device timezone, submits an explicit UTC timestamp, and displays timezone
  information. Slots fall on UTC half-hour boundaries.
- Pending and accepted requests reserve the slot for both participants.
  Rejected, cancelled, or completed appointments release it. The database
  enforces reservations, including simultaneous requests.
- A patient can cancel a pending or accepted request. The selected approved
  doctor can accept/reject a pending request, cancel pending/accepted requests,
  or complete an accepted appointment. A terminal appointment cannot reopen.
  Retrying a transition already made returns the same state without extending
  access or adding another event.
- Acceptance opens a care episode from acceptance until 24 hours after the
  requested start time. Cancellation, rejection, completion, inactive accounts,
  or revoked doctor approval deny review access. Expiry is checked on every
  protected record request and needs no background scheduler.
- Consent covers the patient profile and up to 20 specifically selected records.
  Future and unselected observations are not automatically shared. The booking
  form currently offers the latest 50 saved records. The API checks ownership
  of every selected record before creating any appointment or grant.
- Doctor review is read-only for observations and model results. It cannot run
  predictions, rewrite patient measurements, change risk categories, or bypass
  the locked PE gate. Stored assessments remain readable when new inference
  is disabled.
- Notes have immutable server-set authorship and timestamps. Patients cannot
  write clinician notes, alter note visibility, or edit stored notes. Private
  notes are filtered by the API. History responses contain up to 100 latest
  notes per appointment.
- Permission checks apply to new requests. Content already viewed in a browser
  cannot be recalled from the viewer; refresh checks access again. The review
  screen clears cached content when a request reports revoked access and
  refreshes at the grant's expiry.
- Transition events store actor, appointment, old/new state, and time. They
  do not duplicate reasons, notes, clinical measurements, or model outputs.
  This is appointment auditing, not the full future system audit module.

There is no published clinic availability, external calendar booking, reminder,
message, video session, or automatic care plan in this checkpoint. Requested
times become confirmed only when the doctor accepts. Those remaining features
will use the same participant and episode rules in later updates.

## Verification

The update includes regression tests for consent, roles and ownership, selected
record scope, simultaneous requests, UTC normalization, slot conflicts,
idempotent transitions, terminal states, expiry, doctor approval, immutable
notes, private-note filtering, pagination, and real saved model assessments.
Both the existing research workflow and the session fix remain covered.

Verification counts and platform checks are recorded in
docs/VERIFICATION-0.3.0.md. The Windows installer performs the live PostgreSQL
checks on your machine before changing the development schema.
