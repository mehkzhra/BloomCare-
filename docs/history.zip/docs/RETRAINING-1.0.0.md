# Executed model retraining and evidence

Run date: 16 October 2026. All numbers below come from the included comparison
files. Candidate forests are actual trained, non-executable JSON exports labelled
`INACTIVE_TRAINING_EVIDENCE`; the application does not load them as active models.

## Maternal model

Source: the hash-verified UCI Maternal Health Risk CSV, DOI 10.24432/C5DP5D, CC BY 4.0.
The existing cleaning contract removes exact feature/label duplicates, preserves
conflicting labels, converts Fahrenheit to Celsius and excludes incompatible
record bounds. There are 449 usable rows and 35 measurement groups with conflicting
labels. No synthetic observations or altered outcomes were added.

The existing 359 training / 90 comparison rows and measurement-group boundary are
retained. Each family selects its candidate by five-fold StratifiedGroupKFold
inside the training partition, using macro-F1 and a deterministic recall tie break.
Group overlap is zero. Gradient Boosting weights are calculated inside each fold.

There are 85 configuration evaluations across 84 unique parameter settings: the
Random Forest list deliberately also replays the baseline setting. This is 37
Random Forest, 24 Extra Trees and 24 Gradient Boosting evaluations.

| Selected model | Comparison accuracy | Macro-F1 | MEDIUM recall | HIGH recall | Decision |
| --- | ---: | ---: | ---: | ---: | --- |
| Current Random Forest v0.2 | 71.11% | 0.6671 | 33.33% | 72.73% | Retained |
| Retrained Random Forest | 70.00% | 0.6554 | 38.10% | 63.64% | Not promoted |
| Extra Trees | 66.67% | 0.5960 | 23.81% | 63.64% | Not promoted |
| Gradient Boosting | 67.78% | 0.6407 | 38.10% | 63.64% | Not promoted |

The gate requires no decrease in any of accuracy, macro-F1, MEDIUM recall or HIGH
recall, and a strict macro-F1 improvement. None of these selected candidates pass.
Improving one class alone does not justify replacing the active model when other
measured outcomes worsen.

The historical 90-row results were already known before this task. Model families
were explored sequentially after earlier results; therefore these comparisons are
exploratory internal evidence, not a new untouched test or external validation.
Patient identifiers are unavailable, so zero identical-vector overlap does not
prove patient-level separation. The source's categories are not prospectively
observed complication outcomes. Glucose below 6 mmol/L is absent from this source.

Reproduce on Windows with the existing ML environment:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\retrain-models.cmd
```

Progress prints for each configuration. Outputs go to a new timestamped directory
under `ml\training_reports\runs`; previous evidence and model registration are
retained. Training may take several minutes. Use `--family random_forest`,
`--family extra_trees` or `--family gradient_boosting` for a single family.

## Legacy PE categories

The two original, checksum-pinned workbooks supplied by the old BloomCare source
contain 162 training and 41 test rows. Combining them for a new grouped comparison
and removing exact duplicates leaves 90 rows: 113 duplicates are removed. The
unused, all-missing Doppler columns are omitted. Existing source risk labels are
retained; they are not converted into invented confirmed PE diagnoses.

A new 400-tree Random Forest is fitted to 72 rows with 18 grouped comparison rows.
There is zero identical-feature-group overlap. Its comparison accuracy is 72.22%
and macro-F1 is 0.6619. The old overlapping-split score is not a valid direct
comparison with this result.

This candidate is not promoted. The original source still lacks systolic BP above
130 mmHg, documented HB units and a verified confirmed-PE outcome definition.
Changing the allowed maximum or fabricating higher-BP training rows would not
resolve those gaps. A wider model needs a documented, licensed dataset with the
correct outcome, measurement units, prediction time point and patient grouping,
followed by independent evaluation.

To reproduce against your copy of the original repository:

```cmd
.\scripts\retrain-pe.cmd --source "D:\path\to\original-BloomCare"
```

Only the pinned workbook bytes are accepted. The command does not deserialize the
old pickle or change application activation. Original workbooks are not included
as new patient records in this update.

## Evidence files

- `ml/training_reports/v1.0.0/comparison.json`: final maternal comparison, audit,
  split, baseline, selected candidates and promotion checks.
- Family progress/report JSON: all executed cross-validation configurations.
- Random Forest / Extra Trees candidate JSON: learned trees, feature order,
  class mapping and fitted node weights for portable inspection.
- `ml/training_reports/pe-v1.0.0/pe-retraining-report.json` and `pe-candidate.json`:
  the new grouped legacy comparison and actual inactive fitted forest.

The release manifest records file digests. Unit checks independently replay a
portable forest export against a real fitted model. Honest evaluation and model
registration controls are part of the software quality work; they cannot replace
better clinical data or validation.
