# BloomCare website roles and admin update v0.3.1

Apply this cumulative update to the new BloomCare project after v0.2.2 or
v0.3.0. It includes the appointment files. It contains no old-project code,
model, configuration, accounts or patient data.

## Install in Windows Command Prompt

Stop both app servers. Open Docker Desktop and wait for its engine to run.
Extract the ZIP directly into D:\Desktop\BloomCare, replacing included files.
Do not rerun setup.py, delete database volumes, or reinstall dependencies.

    cd /d D:\Desktop\BloomCare
    .\scripts\update-roles.cmd

The installer starts the database, checks Python dependencies and lint, runs
migration and API tests in a separate temporary local PostgreSQL database,
checks the frontend, then upgrades the development database to
0004_account_activity and checks its schema. It stops on failure.
The existing missing appointments-table error is resolved by successfully
applying 0003 and 0004. Restarting the server alone cannot create these tables.
Expected: Role and admin update passed. Restart the backend and frontend.

Create your first administrator if one does not already exist:

    .\scripts\create-admin.cmd --email admin@example.com --name "BloomCare Admin"

Choose and confirm a password of 12–128 characters. Typing is invisible.
Admin accounts are trusted local setup accounts; public visitors cannot
register as admin or approve themselves. Existing doctor accounts remain
available. No need to recreate a doctor or change their password.

Start the servers in separate CMD terminals:

    .\scripts\start-backend.cmd
    .\scripts\start-frontend.cmd

Open http://127.0.0.1:5173. Readiness can be checked in a third terminal:

    curl.exe --fail http://127.0.0.1:8000/api/health/ready

## Three actor workflow

- Registration offers Patient and Doctor. Doctor fields include registration
  number and specialty. New doctor accounts always await admin approval.
- Login offers Patient, Doctor and Admin. Choose the account's actual role;
  the server rejects a mismatched role. A selector cannot change permissions.
- A pending doctor can sign in and inspect their approval status, but cannot
  receive bookings, list doctor appointments, review records or write notes.
- Sign in as Admin to see accounts, enable/disable patient or doctor accounts,
  approve/revoke doctor approval, list appointments and inspect activity.
  Admin approvals must follow your own verification of professional details;
  typing a registration number is not credential verification.
- Patient and doctor record access remains appointment-scoped and consented.
  Approval alone grants no access to all patient records.
- Account disabling rejects existing sessions on their next request.
  Approval revocation blocks future doctor care requests, including an already
  accepted episode. Already viewed browser content cannot be recalled.
- Existing model evaluation remains in the admin dashboard. Research model
  activation, model files and the unavailable PE model remain as before.

## Test

1. Register a new doctor on the website; sign in as Doctor and see pending.
2. Use another browser/profile to sign in as Admin. Approve the new doctor.
3. Refresh the doctor's overview. It should show approved.
4. As Patient, book the doctor and share selected records with consent.
5. As Doctor, accept, review and write a note. See the corresponding admin
   appointment and activity entries. Click Refresh to update each admin panel.
6. Disable the doctor as Admin. Their next protected request must be rejected.
   Re-enable the account to restore sign-in; check approval separately.

## Activity scope and limitations

The activity panel tracks successful web registrations, logins, logouts,
profile updates, saved health observations, saved assessments, appointment
transitions, clinician-note creation and admin account/approval decisions.
Historical appointment, assessment and note events remain visible. Earlier
logins/profile updates were not recorded and are not reconstructed. Local CLI
account creation and page reads are not logged. This is operational activity,
not a complete read-access or security audit. Passwords, JWTs, note bodies and
clinical measurements are not included in the activity response.

Accounts, appointments and activity are paginated in batches of 50. The
interface has Previous, Next and Refresh controls. Admin account listings show
names, emails, roles, status and doctor registration details. This checkpoint
does not add unrestricted admin browsing of clinical reports or private notes.

## Verification

90 backend tests and 34 frontend tests passed with the existing dependencies.
Backend lint, frontend lint and production build passed. Role tests cover
pending registration, approval, duplicate registration atomicity, forbidden
public admin registration/self-approval, role mismatch, private credential
filtering, account disabling and active-session rejection.
SQLite migrations preserved a seeded existing account, supported downgrade
and reapply of 0004, and matched ORM metadata. PostgreSQL offline SQL compiled.
Live PostgreSQL and native Windows execution are checked by the installer on
your machine; they were not executed in this environment. The existing
Starlette test-client deprecation warning remains.
