# Historical README before v0.9.0

Historical setup and status text. Use COMPLETE-DELIVERY-0.9.0.md for this release.

# BloomCare assessment and interface update v0.7.1

The v0.7.1 update connects the original BloomCare PE forest to the new app as an
additional screening stage for MEDIUM/HIGH maternal results. It includes the
v0.7.0 interface, top video action, grouped patient navigation and report sharing.
See [PE-ASSESSMENT-0.7.1.md](docs/PE-ASSESSMENT-0.7.1.md) for installation, exact
source provenance, coverage limits and validation status. Run
`scripts\update-preeclampsia.cmd` after extracting into the existing project root.

The earlier v0.6.0 workflows remain included:

This cumulative update includes the previous new-project features and adds:

- Family invitations: selected record categories, email-bound invitation codes,
  read-only access, 7/30-day duration, 48-hour acceptance window, expiry and revocation.
- Medication reminders: one-time or 12/24-hour intervals, patient-selected start
  time, cancellation and deduplicated in-app notifications. A background cycle
  runs every 30 seconds while the backend is running.
- Groq assistant integration: explicit consent, optional own-record context,
  English/Urdu response choice, question history and retries without duplicate calls.
- Appointment-linked WebRTC consultation: approved doctor starts, patient joins,
  protected offer/answer/ICE signaling and end-call controls. Media is peer to peer;
  it is not recorded by the application.
- Database analytics and API access audit: actor, method, route template, timestamp
  and status; no query strings, credentials, clinical contents or signaling payloads.
- English/Urdu interface: language selector, right-to-left layout, translated core
  screens/actions/instructions. User-entered text is not automatically translated.
- Backup/restore scripts and optional Docker deployment templates.

## Assessment field change requested

Input boxes show a faint start–end range, with no explanation under a box.
When the registered model is available, those bounds come from its verified
observed training ranges and are enforced by the browser and submit handler.
No measurement is filled or altered automatically. When inference is unavailable,
record-entry bounds are used so records can still be saved. Pregnancy duration
is an observation field and not an input to the six-measurement maternal model.
Server validation and the model's independent range check remain in place.
These are model coverage bounds, not clinical normal reference ranges.

## Install in Windows Command Prompt

Stop both servers. Keep Docker Desktop running. Extract directly into
D:\Desktop\BloomCare, replacing included source files. Keep your .env files,
virtual environment, database volumes, model-trust.json and trained artifacts.
No new package installation, setup reset or retraining is needed.

    cd /d D:\Desktop\BloomCare
    .\scripts\update-remaining.cmd

The installer starts PostgreSQL, organizes imports for the local platform,
checks dependencies/lint, runs migrations and API tests in an isolated local
PostgreSQL test database, checks the frontend, then upgrades the development
schema to 0007_remaining_workflows. It stops on failure.

Expected: Remaining workflows update passed. Restart the backend and frontend.

    .\scripts\start-backend.cmd
    .\scripts\start-frontend.cmd

Run the start commands in separate terminals. Open http://127.0.0.1:5173.
The interface language selector is in the header.

## Configure Groq

    .\scripts\configure-integrations.cmd groq

Enter your Groq API key at the hidden prompt and choose the model ID, or accept
llama-3.3-70b-versatile. This writes only integration settings in backend/.env,
preserving existing database/auth/model configuration. Restart the backend.
Never paste the key into chat or put it in frontend code. A blank key disables
this integration. The assistant displays an unavailable state until configured;
it does not replace a provider response with canned model output.

The endpoint follows Groq's documented chat-completions interface:
https://console.groq.com/docs/api-reference
https://console.groq.com/docs/models

Patient -> Assistant: choose optional context, consent and ask a question.
No other patient's context is accessible. Names, emails and profile data are
not included automatically; user-written questions and selected record text can
contain personal information, which the consent explicitly covers. Explanations
are generated text and may be inaccurate. The assistant cannot modify records,
diagnose, supply PE predictions or prescribe treatment.

## Test family access

1. Patient A -> Family: enter Patient B's account email, select categories,
   choose access duration and consent. Create invitation.
2. Copy the displayed code privately to that person. No automated email is sent.
3. Patient B signs in as Patient using the invited email and accepts the code.
4. Shared with you -> View shared records shows only selected categories.
5. Patient A revokes access; Patient B's next read/download must be denied.

Selected categories include future entries, explicitly stated in the consent.
Only the latest 50 rows per selected category are shown. The grants page shows
up to 100 latest shares in each direction. Family members cannot write another
patient's records, messages or notes. Clinician notes are not a family scope.
App account email registration is not external email-identity verification;
share invitation codes privately with known family members.

## Test reminders

Patient -> Reminders: choose an active medication record, a future time within
90 days and repetition. These are user-entered prescription reminder times,
not app-generated dosage advice. Keep the backend running; after the time and
the next 30-second worker cycle, Notifications shows the reminder. Inactive
medication or disabled patient accounts do not generate reminders. Notification
metadata contains no drug name or dose; the reminders page provides the record.
Cancelled reminders stop. Repetition is a fixed hour interval, not a local
calendar-day schedule; daylight-saving changes can shift local displayed times.
No SMS/email/browser push delivery is included.

## Test consultation

Use an accepted, unexpired appointment. Approved Doctor -> Appointments ->
Video consultation -> Start consultation. Patient uses a different browser
profile/device -> same appointment -> Video consultation -> Join consultation.
Grant camera/microphone permission when prompted. End consultation stops local
media tracks and ends the session; navigation stops local tracks. Permission
loss, expiry, closure or approval revocation denies further signaling.

Default ICE configuration is [] for direct local-network connections. Across
networks, use your own STUN/TURN service:

    .\scripts\configure-integrations.cmd webrtc

Enter the service's ICE server JSON at the hidden prompt, then restart the
backend. Example of the structure (use actual provider values):

    [{"urls":"turn:YOUR-SERVER:3478","username":"YOUR-USERNAME","credential":"YOUR-CREDENTIAL"}]

Do not enter fake credentials for actual calling. Credentials are supplied only
to authorized consultation participants, as required by WebRTC. HTTPS is needed
for camera/microphone on remote deployments; localhost permits local testing.
The signaling history includes connection metadata and is retained in the DB.
Use End consultation before starting another call. Starting a new doctor call
ends an earlier active session for that appointment in the browser workflow.

## Analytics and audit

Admin -> Analytics and audit: real account/appointment counts, symptom severity,
experimental assessment category counts, stored reports/bytes, messages and active
medication records. These are database summaries, not population medical rates.
Request audit includes authenticated reads/downloads and rejected API requests.
Actors are verified from the current session; anonymous/invalid-session requests
remain anonymous. Route templates contain no record identifiers or query text.
Successful login attribution is stored, and audit failures are logged without
sensitive request bodies. Audit is metadata, not a record-content history.

## Backup and delivery

    .\scripts\database-backup.cmd backup

Creates a custom-format PostgreSQL dump in backups/ with a fresh filename.
Never overwrites an existing file. Reports are inside the database and included.
Model artifacts, model-trust.json and .env files must be backed up separately
and protected; .env and model configuration are not included in the dump.

To replace the local database with a chosen backup, stop both servers first:

    .\scripts\database-backup.cmd restore --file "D:\PATH\YOUR-BACKUP.dump" --confirm-restore

Restore is destructive and deliberately requires an explicit confirmation flag.
Then run migrations before starting the servers. A backup can contain patient
data; keep it private. The restore script targets the local compose database.

See DEPLOYMENT-0.6.0.md for the optional container build/proxy configuration and
FEATURE-STATUS-0.6.0.md for implemented features versus remaining dependencies.

## Verification and honest limits

115 backend workflow tests plus 3 delivery-script tests passed (118 tests),
50 frontend tests, Python/frontend lint and frontend production build passed.
Tests cover family scope/recipient/expiry/revocation, reminder deduplication,
provider unavailability and selected own-context/retries with a provider stub,
consultation permissions/signals/end, audit privacy, Urdu/RTL, range placeholders,
backup confirmation and settings preservation. Video UI tests use mock devices.

SQLite migration upgrade/downgrade/reapply and schema comparison passed; prior
medication records were preserved. PostgreSQL offline SQL compiled. Deployment
YAML parses and scripts compile. Live PostgreSQL/Windows checks run locally via
the installer. Actual Groq responses require your key; real camera/audio/network
connections, Docker image builds and a real backup/restore remain local checks.

The imported PE model is available for its supported measurements. LOW maternal
results skip that stage; MEDIUM/HIGH results request additional measurements.
Neither maternal nor PE screening has independent clinical validation. The old
PE dataset has missing columns, duplicate train/test records and undocumented
measurement definitions; its accuracy is not a clinical performance claim.
