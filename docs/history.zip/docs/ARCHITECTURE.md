> v0.3.1 update: website doctor registration, administrator approval, account management and operational activity are now implemented. See ROLES-ADMIN-0.3.1.md for the current behavior and limits.

Current checkpoint: v0.3.0 adds appointments, selected-record consent,
accepted care-episode authorization, clinician notes, and transition auditing.
See [APPOINTMENTS-0.3.0.md](APPOINTMENTS-0.3.0.md) for commands and policies.
The research maternal model remains as documented in the assessment checkpoint.
PE training, care plans, messages, and other remaining features are unfinished.

# BloomCare engineering plan

## Product and current checkpoint

BloomCare is one maternal healthcare workflow, with exactly three account roles: patient, doctor, admin. The supplied master build brief is the requirement source. The latest instruction prohibits reuse of all old project artifacts; this overrides the brief's earlier allowance to reuse serialized models.

The foundation supplies authentication, private profiles/observations, staff provisioning, and the doctor directory. The research assessment and appointment checkpoints extend these same entities. Day 1 remains incomplete while a separate verified PE model and care plans are missing; Day 2 remains incomplete while appointment-linked communication is missing.

## Project structure

| Path | Purpose |
|---|---|
| `backend/app/config.py` | Validated environment settings |
| `backend/app/database.py` | Shared engine/session and declarative base |
| `backend/app/models.py` | Implemented persistent entities |
| `backend/app/schemas.py` | Input/output contracts with unknown input fields rejected |
| `backend/app/security.py` | Password hashing, session JWT, role enforcement |
| `backend/app/api.py` | Implemented route contracts |
| `backend/app/assessment_service.py` | Locked PE trigger and unavailable-model boundary |
| `backend/app/manage.py` | Trusted local staff provisioning |
| `backend/app/main.py` | App setup, health checks, CORS/origin checks, error handling |
| `backend/migrations/` | Explicit versioned database changes |
| `backend/tests/` | Validation, role, ownership, persistence, trigger tests |
| `frontend/src/api.js` | Credentialed API calls and centralized errors |
| `frontend/src/App.jsx` | Session state, registration/login, role-protected routes |
| `frontend/src/pages.jsx` | Database-backed patient, doctor, and admin pages |
| `frontend/src/styles.css` | New responsive visual styling and Tailwind entry |
| `scripts/setup.py` | Generate unique development secrets without overwriting |
| `scripts/check.ps1` | Windows verification sequence |
| `scripts/test_postgres.py` | Migration and workflow tests in an isolated PostgreSQL database |
| `compose.yaml` | Independent PostgreSQL container and persistent volume |

As workflows grow, split routes into `api/{auth,patients,assessments,appointments,communications,records,admin}.py` and business logic into corresponding services. Do not add empty modules or fake endpoints to simulate completion.

## Complete target database plan

All clinical objects have opaque IDs and UTC timestamps. User IDs are foreign keys; clients never choose an owner on a patient self-service mutation. This table distinguishes implemented tables from planned migrations.

| Entity | Main fields / relationships | Status |
|---|---|---|
| User | id, unique normalized email, password_hash, role constraint, active, created_at | Implemented |
| PatientProfile | user_id PK/FK, birth/due dates, phone, language | Implemented |
| DoctorProfile | user_id PK/FK, specialty, unique registration_number, approval | Implemented |
| HealthRecord | patient_id FK, immutable validated observation JSON with explicit units, timestamp | Implemented |
| Assessment | patient_id, health_record_id, model_version, input_snapshot, dataset category, uncalibrated class scores, SHAP, PE status | Implemented; authorized review in v0.3.0; care plan planned |
| PreEclampsiaResult | unique assessment_id FK, screening status, new PE inputs, output, model version, timestamp | Planned |
| Appointment | patient_id, doctor_id, UTC slot, status, reason, consent_at, accepted_at, access_until, closed_at | Implemented in v0.3.0; also represents the expiring care episode |
| AppointmentRecord | appointment_id, health_record_id; immutable selected-record scope | Implemented in v0.3.0 |
| AppointmentEvent | appointment_id, actor_id, old/new status, timestamp; no clinical body | Implemented in v0.3.0 |
| Conversation | unique appointment_id, patient_id, doctor_id, created_at, closed_at | Planned |
| Message | conversation_id, sender_id, body, sent_at, read_at | Planned |
| DoctorNote | appointment_id, immutable author_id, body, patient_visible, timestamp | Implemented in v0.3.0; structured follow-up planned |
| Consultation | unique appointment_id, provider session reference, access window, state | Planned |
| MedicalReport | patient_id, uploader_id, safe storage key, original display filename, MIME, size, checksum | Planned |
| SymptomRecord | patient_id, symptom, severity, observed_at, optional note | Planned |
| Medication | patient_id, name, dosage text, schedule, start/end dates, status | Planned |
| Notification | recipient_id, event_type, object reference, channel, read_at, deduplication key | Planned |
| TimelineEvent | patient_id, event_type, source type/id, timestamp; no second copy of clinical values | Planned |
| FamilyAccess | patient_id, hashed access-grant token, allowed categories, expires_at, revoked_at | Planned |
| AuditEvent | actor_id, action, object type/id, timestamp, minimal metadata without secrets/clinical bodies | Planned |
| ModelVersion | version, artifact hash, original training manifest, dataset provenance, feature schema, true evaluation JSON | Implemented in v0.2.1 |

Use JSONB on PostgreSQL for versioned AI input/output snapshots in future migrations. Core entities and foreign keys remain relational. Historical assessments keep the exact model version and input snapshot used; profile edits do not rewrite their historical results.

### Relationships and multi-doctor authorization

- User → one role-specific profile; patient → many health records/assessments/appointments.
- Patient → appointments ← multiple doctors; there is no hardcoded doctor and no required permanent assignment.
- An accepted appointment establishes the patient–doctor relationship for its care episode. Pending/rejected appointments do not grant record access.
- Appointment → conversation/messages, doctor notes, consultation, notifications and timeline entries.
- A doctor sees only record scope necessary for an accepted episode. Status transitions, expiry and access after completion must have one centralized relationship policy, tested for every read/write route.
- Current consent covers the profile and up to 20 selected saved records. Later or unselected records are not automatically shared. Access starts at acceptance and expires 24 hours after the requested start, or on cancellation/completion. Review reads and new note writes check the centralized policy in appointment_service.py.
- Authored notes remain in the doctor's own history after closure; patient-visible notes remain in the patient's history. This does not renew profile or observation access. The participant-only routes are implemented in appointment_api.py and exposed in the API documentation.
- Patient notes view filters `patient_visible=true`; authorship and ownership are immutable. Patients cannot edit doctor notes.
- Conversations are scoped to appointment participants. A sender cannot supply a different sender_id.
- Family access is a scoped, expiring grant, not a fourth primary actor or an unrestricted shared login. Final access-grant flow must preserve the three-role requirement.
- Passport/analytics/timeline read these same entities; they do not duplicate patient records.

## Implemented API contracts

| Method and path | Actor / purpose |
|---|---|
| GET `/api/health/live` | Public liveness |
| GET `/api/health/ready` | Public database/schema readiness, no sensitive detail |
| POST `/api/auth/register` | Public patient registration only |
| POST `/api/auth/login` | Public credential validation; HttpOnly session cookie |
| POST `/api/auth/logout` | Remove browser session cookie |
| GET `/api/auth/me` | Authenticated current account |
| GET/PUT `/api/patients/me/profile` | Patient's own profile |
| GET/POST `/api/patients/me/health-records` | Patient's own history/save; 50-item pagination |
| GET `/api/patients/me/health-records/{id}` | Patient ownership filter; other patients receive 404 |
| POST `/api/patients/me/assessments` | Patient-owned saved record; research model and SHAP; fails closed if disabled, unsupported, or unverified |
| GET `/api/capabilities` | Authenticated truthful implementation/model status |
| GET `/api/doctors` | Authenticated approved-doctor directory without patient data |
| GET `/api/doctors/me/profile` | Doctor's own account overview |
| GET `/api/admin/stats` | Admin only; aggregate implemented entity counts |

Public registration rejects `role`, `active`, and unknown fields. Staff roles come only from the trusted command in this checkpoint. All browser API calls use the same Vite origin through its proxy. JWTs are not exposed to JavaScript or returned as JSON. Origin checks protect unsafe browser requests alongside SameSite cookies; deploy behind HTTPS with `COOKIE_SECURE=true` before enabling public use.

## Planned API/module architecture

| Module | Planned endpoints / service | Integration and authorization |
|---|---|---|
| Assessment | create/get/history; PE supplemental step, explainability | Patient self; authorized doctor via appointment; one stored result |
| Appointment | doctor availability, create, accept/reject/cancel, history | Patient owner/selected doctor; state-machine validation; notify participants |
| Doctor review | patient record, review flag, notes, follow-up | Valid accepted appointment; immutable authorship; patient visibility filter |
| Communication | appointment conversation/messages/read status | Participants only; no random patient–doctor messaging |
| Records | reports upload/download; symptoms; medication status | Patient self/authorized doctor; private server-controlled file keys |
| Notification | own unread/list/mark-read; scheduler/outbox | Recipient ownership; idempotent reminders; optional channel adapter |
| Passport/timeline | unified own record, authorized doctor view, PDF export | Read from shared source entities; no duplicate copies |
| Assistant | maternal chat with selected stored context | Own patient context only; Groq server key; distinguish guidance from clinical decisions |
| Consultation | join session for existing accepted appointment | Same participants/appointment; short-lived room tokens; no public room URL |
| Family | create/revoke scoped grant, restricted read view | Explicit patient consent, scope, expiry, revocation checks |
| Admin | staff approval/activation, statistics, model evaluation | Admin only; actual evaluated metrics and audited management |

Each future feature needs a schema migration, Pydantic contract, role/object authorization, service, database transaction, frontend states, and tests before being marked complete. New API folders are created as features are implemented, not as empty promises.

## Dependencies and model contract

The tested Python versions are pinned in `backend/requirements.txt`, with resolved transitive constraints. The frontend has exact package versions and a generated `package-lock.json`; install with `npm ci`. Runtime: Python 3.12 and Node 24. Database target: PostgreSQL 16. The tests run on SQLite and, through the supplied script, PostgreSQL.

Future AI packages: scikit-learn, pandas, numpy, joblib/skops, SHAP. Add/pin them only when actual new models are integrated. Recharts, Groq, Twilio, and PDF libraries likewise arrive with working features rather than unused dependencies. Secrets for external services remain backend environment variables.

**Old artifacts reused: none. Fresh artifacts required:**

- A newly sourced, permitted pregnancy-risk dataset and independent train/evaluation code.
- Newly trained Random Forest pregnancy-risk pipeline with preprocessing and feature order in the same artifact.
- Newly sourced PE dataset, independently trained Random Forest PE pipeline and fresh encoders only where necessary.
- Each pipeline's JSON manifest: version, artifact SHA-256, ordered features/types/units, allowed ranges, classes, dataset provenance/licence, split strategy, library versions.
- Genuine held-out evaluation: class-level precision/recall/F1, confusion matrix, accuracy and dataset counts; no synthetic or training-only metric presented as clinical validation.

Do not load arbitrary patient-uploaded pickle files. Only trusted locally generated artifacts may be activated. Use server-side model loading, validate artifact hashes and schema, and fail closed when required artifacts or PE supplemental inputs are missing. Display predictive uncertainty and screening wording accurately. Model evaluation does not establish clinical suitability.

The current observation form is a general record contract; its feature list must be reconciled with independently sourced datasets before activating models. Do not silently use old feature assumptions or rename glucose/temperature units. Preserve records and add a versioned assessment input schema if a new dataset requires different fields.

### Locked PE rule

| Pregnancy model label | Software action |
|---|---|
| LOW | Do not activate PE screening |
| MEDIUM | Activate PE stage automatically |
| HIGH | Activate PE stage automatically |
| Missing/unrecognized | Reject the pipeline; do not guess |

If activated PE needs more inputs, store a pending PE step on the **same assessment**, collect only those extra inputs, then run the fresh PE model. Backend enforces the trigger. This is BloomCare's software rule, not a universal medical screening criterion. Outputs are screening/decision support, not diagnoses.

## Day 1 remaining implementation sequence

1. Run this foundation and complete all checks on the student's Windows machine.
2. Independently source datasets; inspect labels, feature meaning, units, missing data, imbalance, duplicates, subject leakage, and licences.
3. Train preprocessing + Random Forest pipelines using a leakage-safe split; create genuine evaluation and versioned manifests.
4. Add Assessment/PreEclampsiaResult/ModelVersion migrations and model-registry/assessment service.
5. Implement validated one-form assessment; atomically store model version, prediction, explanation, care plan, and conditional PE state.
6. Connect the existing frontend health workflow to real assessment results and any supplemental PE step; keep failed inference distinct from saved observations.
7. Test LOW skips PE, MEDIUM/HIGH activate it, missing inputs/artifacts fail clearly, unauthorized users are rejected, results persist after reload, and doctor access remains closed until appointment authorization exists.
8. Run regression checks, then create `v0.3-patient-assessment` as a stable local Git checkpoint. Day 1 is complete only after this workflow passes.

## Six-day integration sequence

| Day | Work | Required checkpoint |
|---|---|---|
| 1 | Foundation plus new AI pipelines, assessments, PE, explanations/care plan, history | Register → login → one health form → true model → conditional PE → persist → reload |
| 2 | Multiple doctors, appointments, authorized relationships, notes/review, conversation/messages | Patient request → selected doctor accepts → only that doctor sees record → note/message → patient sees allowed content |
| 3 | Reports, symptoms, medication records, timeline, passport | Same underlying patient record powers all views; file/record access checks pass |
| 4 | Reusable notifications, idempotent reminder scheduling, real analytics, English/Urdu translation architecture | Events create recipient-scoped notifications; reminders deduplicate; real aggregate counts |
| 5 | Context-aware Groq assistant, appointment-linked consultation, consent-based family portal | Own stored context only; confirmed appointment participants only; scoped family grant |
| 6 | SHAP integration, genuine model evaluation, security/regression and final demo | Full end-to-end flow passes including unrelated-doctor and cross-patient rejection |

Independently obtaining and validating new training data may affect the six-day schedule. Do not compensate by manufacturing model outputs, using the old artifacts, or declaring incomplete features done.

## Feature contracts for the next two workflows

**Assessment:** input = authenticated patient's validated, unit-labelled observations and optional PE supplemental data; creates = immutable Assessment and activated PE state/result; output = risk, uncertainty, explanation, contextual guidance, PE step; transaction = results and event/notification metadata committed together; connects = history, review, timeline, passport, assistant, evaluation; authorization = patient owner or approved relationship for doctor reads. Test new models, trigger, persistence, failure rollback, and ownership.

**Appointment:** input = authenticated patient, selected approved doctor, future time/reason; creates = requested appointment; transition = selected doctor accepts/rejects, patient cancels; accepted transition creates episode conversation/consultation readiness and notifications in one transaction; connects = access policy, record review, notes, messages, timeline, consultation; test time/conflict validation, idempotent transition, unrelated doctor, cancelled relationship and reminder deduplication.
