# Executed verification — BloomCare 1.0.2

18 October 2026. Checks ran on the actual release source in an isolated Linux environment with SQLite.

| Check | Result |
| --- | --- |
| Full backend regression suite | **236 passed; 1 PostgreSQL-only locking test skipped** |
| Frontend component/integration suite | **130 passed; 0 failed** |
| ML contract/comparison suite | **11 passed; 0 failed** |
| Python Ruff / frontend ESLint | Passed |
| Production frontend build | Passed |
| Original PE forest | Integrity, column mapping and reference scores passed |
| Populated upgrade | v0009 → head0012; historical rows, nullable removal fields, foreign keys and Alembic model parity passed |
| PostgreSQL row-lock SQL | HealthRecord and Assessment lock targets compiled; database execution is not claimed |

New backend coverage verifies owner-only health-record removal, cross-role/other-patient rejection, repeat-safe deletion, validation, old-request protection, atomic rollback on cascade failure, derived-assessment withdrawal, new-sharing exclusion, doctor/family filtering, future assistant-context exclusion and retained note amendments. The admin model-evaluation endpoint remains role-protected.

UI coverage checks visible delete controls in Health history, explicit linked-assessment/audit confirmation, cancellation/focus return, rejected deletion, on-demand deletion logs, patient screening explanation without technical evaluation metrics, honest administrator metrics, and interface/server version mismatch handling.

No model weights, training dataset, split, prediction parameters, input ranges or measured scores changed. Historical v1.0.0 training reports, PDF renders and scoped benchmark remain included as previous evidence.

**Not executed here:** Windows/PostgreSQL release execution, browser visual QA, actual media devices, two-device/TURN calls, live Groq/Twilio delivery, native sharing, HTTPS hosting, backup restoration, deployed load or independent clinical validation. The Windows updater executes the application’s PostgreSQL suite in a disposable database before upgrading the actual installation.

Machine-readable results: `VERIFICATION-1.0.2.json`.
