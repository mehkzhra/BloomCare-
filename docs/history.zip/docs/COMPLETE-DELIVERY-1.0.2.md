# BloomCare 1.0.2 delivery notes

## Screenshot explanation and patient information

The reported patient page displayed the maternal model’s technical evaluation: **71.1% held-out accuracy**, **33.3% medium-class recall** and **90 held-out rows**. These describe an internal test partition; they are not a patient’s personal probabilities or 90 identified patients.

The term training-data leakage refers to possible overlap between records used for fitting and evaluation. That technical limitation is not itself evidence that someone accessed a BloomCare patient’s account or data. This correction does not claim a comprehensive security audit.

Technical metrics and dataset-audit language are now displayed in the administrator’s model-evaluation workspace. Patient pages retain understandable screening limitations, including the possibility of missing medium-risk cases and the need for clinical review. Numbers were not changed or inflated. The old note about no PE training is scoped to the maternal dataset: **the maternal-risk dataset contains no PE outcomes; PE screening uses a separate imported model and additional measurements**. Original historical manifests and trained artifacts are unchanged.

## Complete health-record removal

The prior release added assessment-only removal. This release also adds:

- Owner-only `DELETE /api/patients/me/health-records/{id}` with a reason and repeat-safe response.
- One transaction marks the health record and all active linked assessments as removed. A failure rolls back the whole withdrawal.
- Active source and derived-result filters across patient history, doctor cases and selected-record views, family access, future assistant context, charts, dashboard counters, pregnancy tracking, timeline and passport.
- Deleted records cannot be selected for a new appointment or silently regenerated through an old save/request identifier.
- Pending linked follow-up proposals are withdrawn; active sharing doctors receive an internal notification.
- Original observations, clinical notes and audit information remain stored. Notes show removed-result status. The original note author may amend an existing note under current appointment permissions; this does not restore access to deleted measurements or results.
- An on-demand owner deletion log returns metadata and a reason without returning the removed measurements.

Visible actions are placed in Health history and beside Saved measurements on the record/assessment page. The record-entry form links directly to history. Assessment-only deletion remains available and preserves its underlying measurements; full health-record deletion withdraws both source and linked results.

This is withdrawal from active care with retained audit history. It is not permanent erasure of backups, uploaded independent files, already sent messages or downloaded copies.

## Version and installation verification

The screenshot’s white-sidebar appearance is consistent with an earlier interface, but a screenshot alone cannot establish which files or server process are running. The v1.0.2 footer and on-demand Help version check now make frontend/server mismatches visible without exposing patient information or credentials.

Stop both servers, extract into the existing installation, run `scripts\update-final.cmd`, restart both services, and Ctrl+F5. Confirm **1.0.2** for both interface and server. The updater also checks the frontend package version and required database columns.

Schema head **0012_health_record_removal** adds two nullable columns to health_records: removed_at and removal_reason. The 29-table architecture and existing data are preserved. All earlier modules and migrations remain included. No model retraining, range widening or provider credential replacement occurs.

## Verification and remaining destination checks

See `VERIFICATION-1.0.2.md` and its JSON companion for exact executed results. Tests include ownership, role restrictions, retries, transaction rollback, source/assessment filters, clinician-note retention, provider-context exclusion, visible deletion controls and version mismatch handling.

Actual Windows/PostgreSQL execution, browser visual QA, media devices, live provider delivery, native sharing, deployment load, backup restoration and independent clinical validation remain destination checks. The Windows updater runs the PostgreSQL suite in a disposable test database before applying the application upgrade. Existing PE coverage and model limitations remain unchanged; use the previously verified demonstration cases for software testing.
