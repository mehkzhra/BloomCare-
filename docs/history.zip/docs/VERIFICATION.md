# Checkpoint 0.1 verification

Verified in this build environment using Python 3.12.14 and Node.js 24.19.0.

| Check | Result |
|---|---|
| Backend Ruff lint, including setup/check-support Python scripts | Passed |
| Backend automated suite | 28 passed on an isolated SQLite database |
| Frontend ESLint | Passed |
| Frontend workflow/component suite | 5 passed |
| Clean `npm ci` install followed by Vite production build | Passed |
| Python dependency consistency (`pip check`) | Passed |
| npm dependency advisory check | Zero known vulnerabilities reported at check time |
| Python environment advisory check | Zero known vulnerabilities reported after dependency/tool updates |
| SQLite Alembic upgrade → schema check → downgrade → upgrade → schema check | Passed; no schema drift detected |
| PostgreSQL offline Alembic SQL generation | Passed; migration SQL produced without connecting to a server |
| Setup creates unique secrets and stops rather than overwriting existing config | Passed |

Backend tests cover registration, password hashing, login/logout, duplicate email, invalid registration, denied staff-role selection, anonymous access, invalid credentials, profile persistence, health observation validation/persistence, cross-patient object access, unrelated doctor access rejection, patient/doctor/admin role separation, multiple doctors, expired tokens, disabled accounts, untrusted browser origins, database readiness, unavailable-model failure, and the locked LOW/MEDIUM/HIGH PE rule.

Frontend tests cover protected-route redirection, successful login/empty real-data states, saving numeric observations and showing stored history, patient exclusion from the admin route, and explicit network-error handling. These are component/workflow tests using mocked API responses; backend tests exercise the actual API and database logic.

## Checks that still require the student's machine

- Docker Desktop/Compose startup and PostgreSQL connection.
- Runtime Alembic execution and API workflow tests against PostgreSQL: run `scripts/test_postgres.py` using the command in the README. A temporary PostgreSQL server could not start in this build environment because its process privileges could not be changed to a non-root account. PostgreSQL runtime success is therefore **not claimed**.
- The PowerShell check script was inspected but not executed on Windows.
- Full browser interaction with a running PostgreSQL-backed application was not exercised here. Follow the manual workflow check in the README.

The SQLite suite emits one dependency deprecation warning about Starlette's current `httpx` TestClient adapter; it does not fail a test. No clinical validation, trained-model evaluation, appointment workflow, messaging, consultation, reminders, or advanced AI is claimed in this checkpoint.

Before public deployment, complete the deployment/security work and remaining features listed in the README and architecture plan. Passing a dependency advisory scan is not proof that an application is free of vulnerabilities.
