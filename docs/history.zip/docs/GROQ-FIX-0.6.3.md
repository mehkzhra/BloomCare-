# BloomCare Groq diagnostics and compatibility fix 0.6.3

The latest Windows log shows a working database, signed-in session, notifications,
and assistant status/history. Assistant POST requests return HTTP 502. The prior
code mapped invalid API keys, unavailable models, usage limits, timeouts, network
failures and malformed replies to the same generic message. That log alone
cannot establish which Groq failure occurred.

## Apply to the existing BloomCare installation

Stop the backend, then extract this ZIP into `D:\Desktop\BloomCare` and replace
the included files. Keep the existing environment files and database. No new
dependencies, schema migration, model training or full update installer is needed.

Run in Command Prompt:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\check-groq.cmd
```

The command reads the existing server key, checks the current model list, and
makes one small chat request with fixed connection-test text if the model is
listed. It does not read the database, send patient records, print the API key,
or print the provider's raw response. A listed model still needs chat permission;
only a successful final answer passes the test. The test uses the account's API
usage allowance. There are no automatic retries or model fallbacks.

If the configured model is unavailable, change only its ID while preserving the
key and all other environment settings:

```cmd
.\scripts\configure-integrations.cmd groq-model --model openai/gpt-oss-20b
.\scripts\check-groq.cmd
```

`openai/gpt-oss-20b` is currently listed in Groq's production models; access and
usage remain dependent on the user's account/project. A new default does not
overwrite an explicitly configured model in an existing environment file.

If the key is rejected, configure a valid key privately in Command Prompt:

```cmd
.\scripts\configure-integrations.cmd groq
.\scripts\check-groq.cmd
```

Paste the key at the hidden prompt, press Enter, and enter an accessible model
ID (or accept the new `openai/gpt-oss-20b` default). Do not share the key or `.env`.

After the test passes:

```cmd
.\scripts\start-backend.cmd
```

Refresh the website and ask a short question in Assistant. Test optional record
context only after the connection works and the patient has consented.

## Error meanings

| Code | Action |
| --- | --- |
| GROQ_NOT_CONFIGURED | Configure the server API key. |
| GROQ_INVALID_KEY | Create/use a valid Groq key and configure it privately. |
| GROQ_PERMISSION_DENIED | Check project/model permissions in Groq Console. |
| GROQ_MODEL_UNAVAILABLE | Select a model available to this account. |
| GROQ_REQUEST_REJECTED | Check model support/request settings; try less context. |
| GROQ_RATE_LIMIT | Wait and check Groq account rate, usage and quota limits. |
| GROQ_TIMEOUT / GROQ_NETWORK | Check the server's internet connection, proxy and firewall. |
| GROQ_OUTPUT_LIMIT | Ask a shorter question; the incomplete answer was not saved. |
| GROQ_INVALID_RESPONSE | The provider did not return a usable final answer. |
| GROQ_UNAVAILABLE | Retry later after the provider recovers. |

The API preserves the local login session even when Groq rejects its server key.
Terminal warnings contain only a fixed error code and upstream HTTP status,
never the key, question, records or raw provider message. Failed replies are not
stored as answers. Consent, record selection, ownership, retry IDs and local
request limits continue to apply.

GPT-OSS models now use `max_completion_tokens`, a larger reasoning/output budget,
low reasoning effort and `include_reasoning=false`. Only final answer content is
saved; incomplete or reasoning-only responses fail clearly. Other models do not
receive GPT-OSS-specific parameters. No clinical prediction model is changed.

Automated checks use mocked Groq responses to cover the documented errors and
privacy behavior. Real account/key/model/network verification occurs when the
user runs `check-groq.cmd`; it was not performed with the user's credentials here.

References checked on 2026-10-15:
- https://console.groq.com/docs/models
- https://console.groq.com/docs/errors
- https://console.groq.com/docs/reasoning
