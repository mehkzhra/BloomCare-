# Requirements and design addendum — v1.0.2

18 October 2026. Existing requirement mapping and model-evaluation evidence remain available. This change closes the reported correction/discoverability gap and clarifies patient information.

| Area | Behavior |
| --- | --- |
| Patient comprehension | Model test statistics and dataset-audit terminology live in admin evidence; understandable model limitations stay on the patient result page. |
| Record correction | An owner can confirm removal of a mistaken health record and all linked assessments from active care. Assessment-only removal remains distinct. |
| Authorization | Server-side ownership and role checks protect deletion. Active appointment consent still governs clinical access. Removed records cannot be newly shared. |
| Consistency | Source and dependent results are withdrawn in one transaction. Histories, analytics, family access and future provider contexts use active records only. |
| Accountability | Original observations and clinical decisions remain auditable. Note amendments preserve the original chain and cannot restore deleted-result access. |
| Discoverability | Delete actions appear on Health history and saved-measurement detail; record entry links to history. |
| Installation clarity | Footer version and on-demand interface/server comparison reveal incomplete updates. Additive migration0012 and required-column checks identify the current release. |

No trained model, evaluation score, source split, model coverage or clinical-validation status changes. Previous training reports remain historical evidence; this is a software workflow update.
