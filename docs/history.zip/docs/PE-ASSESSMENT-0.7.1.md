# BloomCare PE assessment and interface v0.7.1

This patch is for the existing new BloomCare project with the v0.6.3 Groq fix.
It includes the complete v0.7.0 interface changes, so a separate interface ZIP is
not required. Extract into `D:\Desktop\BloomCare`, with the ZIP's `backend`,
`frontend`, `ml` and `scripts` folders merging into the existing folders.

## Apply on Windows CMD

Stop the backend and frontend. Start Docker Desktop, extract the update into
the project root and allow replacement of these application files. Then run:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\update-preeclampsia.cmd
```

The script checks installed dependencies, Python lint, PE artifact integrity,
temporary PostgreSQL migration/API tests, frontend lint/tests/build and finally
applies migration `0009_pe_screening` to the configured application database.
It starts the existing local Compose database if needed. It does not install
new packages, retrain the maternal model or edit `.env`, passwords or Groq keys.
If a check fails, it stops before applying later steps; keep the error output.

Start the servers in separate CMD windows:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\start-backend.cmd
```

```bat
cd /d D:\Desktop\BloomCare
.\scripts\start-frontend.cmd
```

Refresh the website with **Ctrl+F5**.

## What the patient sees

1. Run the existing maternal assessment on a saved health record.
2. A MEDIUM/HIGH result opens **Pre-eclampsia screening** inside that assessment.
3. Age, pregnancy weeks and blood pressure come from the immutable saved record.
4. Enter nine additional values: pregnancies, previous births, BMI, diagnosed
   diabetes, hypertension history, haemoglobin, fetal weight, urine protein and
   amniotic-fluid measurement. Yes/no inputs start unselected. Unknown values
   must not be guessed.
5. Number inputs have faint start–end placeholders. These are model coverage
   bounds, not normal medical reference ranges. Out-of-range actual saved values
   prevent PE inference and offer a doctor-review link.
6. The actual legacy forest returns a **PE model category** and class scores.
   The result, observations and model provenance are saved once. Retrying the
   same submission returns the saved result. Different measurements require a
   new health record; existing results are not overwritten.

LOW maternal results do not open PE under the requested software gate. This
does not exclude PE. The chatbot stays a separate question assistant and never
generates a PE prediction.

Saved PE results appear in assessment history and the accepted doctor's view
of a specifically shared health record. Revoking/ending the care episode ends
doctor access. Other patients and unassigned doctors cannot read or create them.
Saved results remain readable if the PE model later becomes unavailable.

## Exact original source and compatibility

- Repository: https://github.com/mehkzhra/BloomCare
- Immutable commit: `e7bce42d00a7c5813964a6b2d6f1cd5142cab518`
- Original forest: `ml/models/preeclampsia_model.pkl`, SHA-256
  `4959ef608bd58ece855566d292c1940be3edf0ddb0e1028ea8923f2c887032bd`
- Original encoder: `ml/models/preeclampsia_label_encoder.pkl`, SHA-256
  `1f512be8ebcbe7f813a945d16e13849e7b14f2a0f02a55e50a85fff01c186d2c`
- Original training recipe: `ml/train_preeclampsia_model.py` in that commit.
- All original file hashes and conversion checks are in the delivered manifest.

The original artifact identifies scikit-learn 1.8.0; the existing new app uses
1.9.1. Cross-version pickle loading is unsupported by scikit-learn:
https://scikit-learn.org/stable/model_persistence.html

For this one-time offline conversion, the exact owner-authorized, hash-pinned
forest and encoder were inspected, and their fitted tree arrays were exported
to plain JSON. The server reads only that pinned JSON: no old pickle is loaded,
no old model-serving code runs and the existing dependency versions stay intact.
The 200 original trees and class order are retained; `high/low/mid` maps to
`HIGH/LOW/MEDIUM`. No new rules or fallback risk score were added.

Conversion comparisons covered 203 source rows, 512 deterministic synthetic
vectors and 14,928 split-boundary vectors, including float32 input behavior.
Maximum class-score difference was approximately `6.66e-16`. The comparison
reference was the original pickle loaded in the current export environment,
which emitted version warnings; it was not run under its original 1.8.0 training
environment. These are numerical compatibility checks, not medical validation.

## Known source limitations

The model was fitted to 162 rows. Its nominal 41-row test set contains only 25
unique input combinations, and 25 test rows match training inputs. Its measured
90.24% legacy test accuracy is therefore not independent evidence. Some identical
training inputs also have different labels. Clinical outcome definitions,
dataset origin, licensing and external validation are not documented there.

Both Doppler columns are entirely empty in training and unused by every tree.
They are not collected in the new form and no Doppler values are fabricated.
The source only calls haemoglobin `HB` and provides no documented unit; the UI
preserves that label instead of asserting a unit. Source measurement definitions
need confirmation before clinical use.

Training systolic BP covers only **90–130 mmHg**. Other source values include
diastolic BP down to 20 and fetal weight from 0.0001 to 9.55 kg. These values
require clinical and data-quality review. Do not alter actual measurements to
fit the model. The UI discloses these limitations under model information.

This is an implemented legacy screening component. It cannot confirm or rule
out pre-eclampsia, and its scores are not disease probabilities. Independent
clinical validation remains pending.

## Verification

- 169 backend tests passed; the PostgreSQL-specific row-lock test was skipped
  under local SQLite. The Windows installer runs that suite on PostgreSQL.
- All 77 frontend tests passed, with frontend/Python lint and production build.
- PE integrity and reference-score verification passed.
- Disposable SQLite migration upgrade/downgrade/reapply and schema comparison
  passed while preserving an existing maternal assessment. PostgreSQL migration
  SQL compiled; a live PostgreSQL run was not performed in this environment.

Real-model API tests cover the MEDIUM/HIGH gate, LOW skip, input validation,
patient ownership, doctor role/sharing/expiry, immutable snapshots, duplicate
submits, missing/tampered model behavior and reading saved results offline from
the model. Frontend tests cover blank numeric/yes-no inputs, faint range hints,
locked base readings, actual submitted fields, saved results, errors and clinician
read-only display. Full suite results are recorded in the release delivery.

The Windows script performs PostgreSQL checks on the user's local machine.
Real WhatsApp handoff, camera/video and desktop/phone visual checks still require
the user's browser; this update does not claim those were exercised here.
