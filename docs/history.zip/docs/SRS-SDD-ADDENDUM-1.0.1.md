# SRS / design addendum — v1.0.1

17 October 2026. This update implements the reported privacy, visual hierarchy, correction and service-status gaps. Earlier requirement mapping and actual model-evaluation reports remain in the package.

| Area | Acceptance behavior |
| --- | --- |
| Privacy and access | Current role controls the privacy content and relevant navigation. API roles and ownership remain authoritative. No secrets are exposed in diagnostic responses. |
| Record correctness | Owner supplies a reason and confirms deletion of an erroneous assessment. An immutable audit copy remains; active clinical queries and analytics exclude the removed result. Existing clinician notes/reviews stay labelled and scoped. |
| PE workflow | Exact source-model limits, affected readings and unavailable/no-result reasons are distinct from missing measurements. The clinician workflow remains available without a PE prediction. |
| Interface | Shared navy structure, one accent per role, semantic risk colours, responsive privacy cards, on-demand deletion log and service instructions. |
| Video and availability | Parsed direct/STUN/TURN/invalid configuration modes replace the old string comparison. Local device checks release tracks on stop, cancellation and unmount. Live connectivity remains separately verified. |
| External sharing | Manual PDF sharing and automatic Twilio alerts have separate instructions. Sandbox joining, active window and registered-sender template conditions are explained. |
| Maintainability | The API and Windows wizard reuse one pure ICE validator. Additive migration 0011 preserves the previous schema’s rows. Current versioned delivery checks identify the new columns and UI assets. |

The 29-table architecture is retained. Two nullable assessment lifecycle columns record removal time and reason. Original measurements, trained artifacts, model trust, accounts and historical clinician decisions are preserved. Removal does not erase already exported copies or existing backups.

Verification covers authorization, ownership, projection filters, retries, invalid configuration and device cleanup. Browser visual QA, Windows/PostgreSQL execution and live services must be checked on the destination environment; clinical validation remains outstanding.
