# BloomCare reports, messages, notifications and form improvements v0.5.0

## Features

- Reports: private PDF/PNG/JPEG uploads, paginated list, downloading, deletion,
  explicit appointment-based consent sharing and revocation. Report metadata
  now appears in the patient timeline and health passport summary.
- Messaging: patient/selected-doctor conversation linked to an appointment.
  New messages require an accepted, unexpired care episode. Previous messages
  remain readable to participants after closure, subject to account/doctor status.
- In-app notifications: appointment request/status, new message, report sharing
  and patient-visible clinician note. Unread count, pagination and mark-read.
- Login and registration: Show password / Hide password option, without changing
  the entered password or submitting the form.
- Health observations: labelled demo example placeholders, units, entry limits,
  and verified assessment coverage when the model is available. No values are
  prefilled. Coverage comes from the registered model, not hard-coded medical
  ranges. Examples and model ranges are not normal clinical reference ranges.

## Install (Windows Command Prompt)

Stop both app servers. Open Docker Desktop and wait until its engine is running.
Extract the ZIP into D:\Desktop\BloomCare, replacing included files. It is a
cumulative source update for the new project and includes earlier care/role files
and the booking-test fix. Keep .env files, virtual environment and model artifacts.
No dependency installation, setup reset or retraining is required.

    cd /d D:\Desktop\BloomCare
    .\scripts\update-communication.cmd

The installer starts PostgreSQL, fixes platform import ordering, checks
Python dependencies/lint, runs migrations and all API tests in a separate
local temporary PostgreSQL database, checks frontend lint/tests/build, then
upgrades the development schema to 0006_reports_messages and compares it
against the models. It stops on failure and never drops the development database.

Expected: Reports, messaging and notifications update passed. Restart the backend and frontend.

Start in two separate CMD terminals:

    .\scripts\start-backend.cmd
    .\scripts\start-frontend.cmd

Open http://127.0.0.1:5173. Existing accounts, approvals, records and model
activation remain available. The existing model assessment/PE restrictions
are unchanged.

## Test

1. At Login or Register, enter a password and use Show password / Hide password.
2. Sign in as Patient. Health record shows example numbers but empty inputs.
   Enter actual measured values. Records outside model coverage can still be
   stored; the model rejects unsupported inference rather than changing values.
3. Reports: enter a title and upload a PDF/PNG/JPEG. Refresh and download it.
4. Book a future appointment with an approved doctor. The doctor sees a request
   notification. Sign in as Doctor in another browser profile and accept.
5. Patient → Reports → Share with your doctor: choose the accepted appointment,
   check consent, select Share report. Only the specifically selected file is shared.
6. Appointments → Messages and reports: Patient sends a message; Doctor opens
   the same appointment, replies and downloads the consented report.
7. Notifications: check unread items and mark one read. Header counts and message
   history refresh every 15 seconds while open; Refresh buttons work immediately.
8. Revoke a report's sharing as Patient. New doctor download requests must fail.
   Cancellation/completion/expiry or approval revocation also denies downloads
   and new messages. Participant message history remains after closure.
9. Sign in as another patient or unrelated doctor: reports/messages must not leak.
   Private clinician notes do not generate patient notifications.

## Storage and scope

Reports are stored as database binary content, privately served as attachments
with non-cacheable responses and fixed safe download filenames. Maximum 5 MB
per file, 50 MB total and 100 files per patient. Type/signature checks are provided;
full document parsing and malware scanning are not included. There is no inline
file execution, OCR, or automated interpretation. Use a local PDF/image viewer
for downloaded files. Report bytes are not embedded in the passport export;
it contains report metadata in the recent timeline summary.

Deleted reports are removed from application tables and their shares are revoked.
Already downloaded copies and existing database backups cannot be recalled.
Report permissions are checked on each download; prior consent does not grant
access to new files. Doctor/admin general account approval does not grant
unrestricted report access.

Messages support server-enforced retry identifiers so retrying a successful
request cannot create a duplicate message or notification. Message bodies are
not included in notification metadata or the admin activity listing. Admin
activity records report uploads/deletions/sharing and message-send events.
The system does not yet audit every read. Messaging is not an emergency service.

Notification polling is in-app only. This update does not add SMS, email, browser
push, medication scheduling reminders or retroactive alerts for earlier events.
The report-sharing selector offers the latest 50 appointments and reports.
Patients can navigate older report pages. Messages/notifications use 50-item
pages. The current accepted care episode policy remains unchanged.

## Verification

107 backend tests and 45 frontend tests passed here. Python/frontend lint and
production build passed. New tests cover file-type/signature/size rejection,
report ownership and binary roundtrip, consent, sharing/revocation, deletion,
message isolation/retry/closure, notification ownership/private-note filtering,
password visibility, empty demo placeholders, upload requests and consent UI.

SQLite migration upgrade/downgrade/reapply, binary persistence and schema
comparison passed. Existing accounts and medication records were preserved.
PostgreSQL offline SQL compiled. Native Windows and live PostgreSQL are checked
locally by the installer; they were not executed here. The earlier Starlette
warning remains and does not represent a failed test.
