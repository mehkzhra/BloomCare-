# BloomCare colour and compact assistant update v0.8.0

An interface update for the existing v0.7.1 PE project. The Windows frontend
test timing fix from v0.7.2 is included.

## Apply on Windows CMD

Stop the frontend, extract this ZIP directly into `D:\Desktop\BloomCare`, and
allow replacement of its frontend files. Run:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\update-interface.cmd
```

Restart the frontend using `scripts\start-frontend.cmd`, then refresh the browser
with **Ctrl+F5**. This interface update needs no new package installation or
database migration.

If the earlier PE update stopped after its successful 170-test PostgreSQL run
and `finish-preeclampsia.cmd` has not yet completed, use that included finish
command instead of `update-interface.cmd`. It also checks the frontend and
applies the still-pending PE migration before the servers restart. Details are
in `WINDOWS-UI-CHECK-FIX-0.7.2.md`.

## Visual changes

The palette combines deep teal navigation, warm ivory backgrounds, peach hero
highlights, and mint, sky and plum feature accents. Dashboard figures continue
to come from actual records and appointments. The assistant has its own plum
colour treatment, clearer input hierarchy and compact privacy/context controls.
The landing page, account forms, tables, buttons, doctor cards and browser icon
share the same palette. Mobile header spacing and Urdu/RTL styles are included.

## Compact question history

- History is closed on entry and its API request starts only when opened.
- Opening shows compact question rows; selecting one reveals its complete
  question and reply. One reply is expanded at a time.
- Search matches both question and answer text within the loaded history.
- The existing API returns the latest 50 questions. The interface states that
  limit when 50 entries are returned.
- Long open lists scroll inside a bounded panel. Closing the history removes
  that panel's contents and cancels an in-progress read.
- A newly saved answer appears in the main reply area. An open history refreshes
  after a successful save; a closed history stays closed and does not fetch.
- Closing the panel does not delete stored questions or answers.

Suggested-question chips fill and focus the question draft. They do not submit
a request, select context or grant consent. Sending still needs the patient's
explicit consent; only selected record categories are included. Retry IDs are
preserved for an unchanged failed request and renewed when its question,
context or language changes.

## Verification and live checks

All 88 frontend tests passed, with lint and the production build. This is a
frontend update; the backend/API model checks from the previous release apply.

The frontend suite exercises lazy history loading, full reply expansion,
single-answer selection, search, empty/error/retry states, consent, selected
context, suggested drafts, history refresh after save, cancellation and Urdu.
Existing role, appointment, PE, report-sharing and sign-in tests also run.
Core sidebar/button/history text-colour pairs were checked for contrast.

Desktop/mobile browser appearance, real Groq responses, camera calls and native
WhatsApp handoff were not exercised in this environment. Check the finished
interface in the Windows browser, including a phone-width view and Urdu mode.
No fixtures or sample replies are added to the running application.

## Suggested next design improvement

An optional next step is a BP/glucose trend view built from the patient's actual
dated observations, with clear units and an empty state until enough records
exist. A doctor-availability calendar can then make appointment selection clearer.
These are suggestions, not features included in this update.
