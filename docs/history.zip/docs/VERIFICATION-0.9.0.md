# BloomCare v0.9.0 verification

Checked 16 October 2026 in the Linux build workspace. These are executed results,
not claims that the Windows machine or external accounts were accessed.

| Check | Result |
| --- | --- |
| Backend suite | **187 passed, 1 skipped**, 42.99 seconds. One PostgreSQL lock-specific case skips under the isolated SQLite test configuration. |
| Added delivery/migration coverage | 18 passing cases are included in the backend total. They exercise the actual trained classifier/PE forest, provider effects mocked. |
| Frontend suite | **95 passed, 0 failed**, including seven new unit-conversion, retry, consent/review/follow-up/reschedule/alert cases. |
| ML data-contract suite | **7 passed**, 1.01 seconds. |
| Python lint | Ruff check for backend, scripts and ML: passed. |
| Frontend lint | ESLint: passed. |
| Production build | Vite build: passed. CSS about 44.25 kB; JS about 496.91 kB before gzip. Vendored PDF runtime/fonts load separately when needed. |
| Original PE artifact | Pinned forest integrity, column mapping and reference score checks: passed. |
| PE SHAP | Actual fitted node weights, saved forest score parity and additive contribution checks: passed. Unused Doppler features contribute zero. |
| Migration | Populated SQLite v0009 -> v0010 upgrade, preserved historical data, foreign keys and Alembic metadata check: passed. |
| PDF export | Actual shipped jsPDF/font code generated a 3-page English report and 4-page Urdu-content report with long saved-guide text and note amendment. Poppler page rendering inspected; Urdu direction/glyph omissions fixed before delivery. |

Backend regression coverage includes authentication, doctor approval, ownership,
appointment states/slot conflicts, selected-record access, notes, uploads, report
grants, messages, reminders, assistant failures/history, family revocation,
consultation signaling, audit behaviour and actual model artifacts. New tests add
one-form retry deduplication, warning-triggered PE, unsupported-value preservation,
consistent completed PE summaries, saved care-guide provenance/failure handling,
review concurrency/notifications, note amendments and safe PDF data, scoped
search, follow-up consent, rescheduling revocation and Twilio request/status paths.

The frontend checks cover the retained interface and new clinical flows. Actual
Groq/Twilio calls are mocked in automated tests; synthetic QA PDF content is not a
patient report and is not distributed as a real assessment.

## Destination verification still needed

The combined Windows command runs fresh migrations, Alembic check and the full
API suite against a separate temporary local PostgreSQL database before migrating
the application's database. Its PostgreSQL-specific result remains to be observed
on the user's host; the local SQLite pass is not substituted for it.

Not executed in this workspace: real WhatsApp delivery/sender-template approval,
real Groq response with the user's key, native-device sharing, cross-device video
media/TURN, deployed HTTPS/cookie configuration, backup restoration, production
load/100-user response-time target or independent clinical validation. Component
tests/build checks do not establish those results.

One existing Starlette/httpx deprecation warning remains in the backend test
environment; it did not fail the suite. PDF rendering can emit an Adobe-Identity-H
font-collection notice; the rendered output, including Urdu joined letters and
punctuation, was inspected rather than relying on text extraction alone.

The ZIP contains source, migrations, required PE JSON and offline PDF assets.
Credentials, account passwords, live records, uploads, backups and the already
trusted maternal model are excluded and retained in the destination installation.
