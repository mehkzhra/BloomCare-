# BloomCare loading fix 0.6.2

The uploaded log shows repeated connection timeouts to PostgreSQL at
`localhost:5433`, followed by login HTTP 500 errors. The API was running while
the database was unreachable. Reminder and audit warnings have the same cause.

## Apply to the existing BloomCare folder

1. Stop the backend and frontend. The uploaded log already shows a clean backend shutdown.
2. Extract this ZIP into `D:\Desktop\BloomCare`, allowing its included files to replace existing files.
3. Open Docker Desktop and wait for its engine to run.
4. Open Command Prompt and run:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-backend.cmd
```

The script checks the actual database connection. If the usual local PostgreSQL
port is unavailable, it starts the existing Compose `db` service and waits for
its health check. It then checks the configured database credentials again.
It starts Uvicorn only after this succeeds. Docker failures stop startup with
recovery instructions. A healthy existing connection needs no Docker command.

In another Command Prompt:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\start-frontend.cmd
```

Open http://127.0.0.1:5173 and press Ctrl+F5 once to refresh the frontend.
No dependency reinstall or database migration is required by this patch.
The ZIP contains source, tests, and this document; it contains no `.env`,
accounts, database backup, dependencies, or model artifacts.

## Failure behavior

- New PostgreSQL connections have a three-second timeout per attempted address;
  `localhost` may try both IPv6 and IPv4. Pool checkout waits are also bounded.
- Database connection/pool errors return a safe HTTP 503 response. The request
  does not open a second failed audit connection before showing that response.
- Anonymous session checks do not open an audit database connection.
- Session checks, login, registration, and ordinary reads have a 15-second
  browser deadline covering both fetch and response body. Most other writes
  have a 30-second deadline; the assistant retains 60 seconds.
- Navigation cancellation remains separate from a timeout. Timeouts and HTTP
  503 responses do not sign a user out or automatically retry a write. If a write
  times out, check saved records before submitting it again.
- This patch starts the existing local service, preserves named volumes, and
  never resets credentials or changes database URLs. It cannot open Docker Desktop
  on the user's behalf or repair an external database/network failure.

## Manual recovery if Docker still cannot start

Run from `D:\Desktop\BloomCare`:

```cmd
docker compose up -d --wait db
docker compose ps
```

The `db` service must report healthy. If it does not, inspect the Docker error
and keep the database volume and existing environment files. Share the terminal
error rather than environment files, passwords, or API keys.

## Verification

Backend tests include a real local TCP peer that accepts a PostgreSQL connection
but never completes its handshake, plus outage/recovery, safe errors, no repeated
audit connection, and local startup failure tests. Frontend tests cover a stalled
session, stalled response body, retry after timeout, cancellation, 503 handling,
and no automatic retry of writes. The actual Windows Docker startup still needs
to be verified on the user's machine.

Reference behavior:
- https://docs.docker.com/reference/cli/docker/compose/up/
- https://www.postgresql.org/docs/current/libpq-connect.html
- https://docs.sqlalchemy.org/en/20/core/engines.html
