# BloomCare four-feature update v0.4.0

This cumulative patch extends the new independent BloomCare application with:

1. Symptom tracking: description, severity, occurrence time and paginated history.
2. Medication tracking: name, prescribed dose/schedule, prescriber, active/inactive status.
3. Unified patient timeline: observations, stored assessments, symptoms, medication
   records, appointments/transitions and patient-visible clinician notes.
4. Health passport: profile, active medication records and recent timeline;
   download a self-contained HTML summary or use Print / Save PDF.

## Install in Command Prompt

Stop both servers with Ctrl+C. Keep Docker Desktop running. Extract directly
into D:\Desktop\BloomCare, allowing replacement. Keep existing .env files,
accounts, database volumes, virtual environment and trained model artifacts.
No dependency installation, setup reset or model retraining is needed.

    cd /d D:\Desktop\BloomCare
    .\scripts\update-care.cmd

The installer starts the database; fixes import ordering for this platform;
checks Python dependencies and lint; runs migrations and all backend tests in
an isolated temporary local PostgreSQL database; then checks the frontend.
Only after checks pass does it upgrade the development schema to
0005_patient_care and compare it against the ORM models. It stops on failure.
The database is not dropped. The prior booking-test setup fix is included.

Expected: Patient care update passed. Restart the backend and frontend.

Start in two separate Command Prompt terminals:

    .\scripts\start-backend.cmd
    .\scripts\start-frontend.cmd

Open http://127.0.0.1:5173 and sign in with your existing patient account.
New navigation: Symptoms, Medications, Timeline, Health passport.

## Test the four features

- Symptoms: save a demo symptom with past occurrence time. Refresh and verify
  it persists. Device timezone is converted to UTC; future and timezone-less
  timestamps are rejected by the server.
- Medications: record a prescribed medication. Mark its record inactive, then
  active. Refresh and verify the status persists. This changes only the record,
  not the prescription. Do not change treatment based on an app status button.
- Timeline: verify the symptom and medication appear alongside existing care
  events in descending time order. Previous/Next retrieves batches of 50.
- Passport: verify your profile and medication list. Download the HTML file;
  open it locally to view the summary. Use Print / Save PDF and choose Save as
  PDF in the browser dialog. Patient content is escaped in the HTML export.
- Sign in as another patient: their entries, timeline and passport must be
  separate. Doctors/admins cannot call these patient-only endpoints.
- Admin activity shows the new symptom/medication saves and medication-status
  updates through the existing activity panel.

## Scope

These are patient-entered records. Medication schedules are text records;
background reminders and notifications are a later module. Symptoms do not
produce diagnosis or triage predictions. Export is a portable summary, not an
identity credential or verified clinical record. It includes up to 100 recent
care events and 100 active medications, with visible limits. Medication rows
show their current status; this is not a complete historical prescription ledger.

New symptom/medication entries are private to the patient. This update does
not silently extend prior doctor consent grants to these new data types.
Private clinician notes are excluded from timeline and passport. Existing
assessment validation, model limitations, PE gate and activation remain unchanged.
Report uploads and other planned modules will be integrated in later bundles.

## Verification

99 backend tests, 38 frontend tests, Python/frontend lint and production build
passed here. Tests cover ownership, role restrictions, stored medication
status, invalid/forged input, timezone conversion, private-note filtering,
timeline ordering and escaped passport export. The full previous appointment
and role suite remains included.

SQLite upgrade/downgrade/reapply and Alembic schema comparison passed; an
existing account was preserved during upgrade. PostgreSQL offline SQL compiled.
Native Windows and live PostgreSQL are verified locally by the installer;
these checks were not executed here. Existing Starlette warning remains.
