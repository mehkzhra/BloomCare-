# BloomCare interface update 0.7.0

This update changes the existing BloomCare frontend. It uses the working API,
accounts, observations, appointments, reports, notifications and assistant.
It does not replace the project, reset data or configure any secret.

## Install on Windows

1. Stop the frontend Command Prompt with Ctrl+C. Keep the existing project folder.
2. Extract the ZIP into `D:\Desktop\BloomCare`, replacing its included files.
3. From Command Prompt run:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\update-interface.cmd
```

After the interface checks pass:

```cmd
.\scripts\start-frontend.cmd
```

Open http://127.0.0.1:5173 and refresh with Ctrl+F5. The running backend can remain
in its existing window. If it is stopped, use `scripts\start-backend.cmd` in a
separate Command Prompt as before. This patch needs no dependency installation,
database migration, training, new password or API key.

## Interface changes

- Calm sage, forest green and warm neutral surfaces; a consistent typography,
  spacing, icon and form system across all existing modules.
- Six main patient navigation items: Overview, Health record, Assessments,
  Appointments, Reports and Assistant. History, Symptoms, Medications, Reminders,
  Timeline, Health passport, Family and Profile remain in the expandable
  **More care tools** menu. A selected secondary page opens this group.
- Video consultation is at the top of patient and doctor workspaces. Its new
  hub lists accepted appointments with current access. It uses existing
  appointment-scoped call routes; it does not create calls with arbitrary users.
- The patient dashboard uses saved observations for pregnancy duration and
  blood pressure, shows an upcoming appointment when available, and provides
  report, reminder, assessment, family and assistant shortcuts. Empty values are
  not filled with invented records, doctors or predictions.
- The assistant remains a separate feature for questions. Assessment results
  remain in Assessments.
- Notifications use a compact icon and unread badge. Desktop navigation becomes
  a menu drawer on smaller screens. Menus and report dialogs support Escape,
  keyboard focus handling and labelled controls. English/Urdu switching and RTL
  layout are retained, with translations for the new interface copy.
- Admin accounts have a dedicated `/admin/accounts` screen and navigation entry.
  The overview links to account management and analytics/audit.
- Landing, About, Privacy & sharing and Help & support pages describe the real
  product workflows. Repeated demo/research wording is removed from frontend
  headings and navigation. Relevant screening limitations remain on assessments.
- Health-entry range placeholders remain faint and empty. No actual measurement
  is changed to fit a model range.

## WhatsApp report sharing

Reports now have a WhatsApp action. The dialog prepares the authenticated report
file and requires the patient's choice to share a copy outside BloomCare.

- Where file sharing is supported, **Choose WhatsApp** opens the device share
  menu with the actual file. The user selects WhatsApp and confirms the recipient
  and send action in that app. The browser cannot force a particular share target.
- **Download & open WhatsApp** downloads the file and opens a chat composer with
  generic text. The user attaches the downloaded file before sending. A `wa.me`
  link alone cannot attach a local file.
- The WhatsApp URL contains no report title, patient name, API download URL,
  record identifier, cookie or access token. The report download still requires
  its existing owner session. No public report endpoint is added.
- Sharing a copy does not grant doctor access inside BloomCare, and revoking an
  appointment share cannot recall a copy already sent outside the app.
- Cancellation is shown as cancellation. The app does not claim that a WhatsApp
  recipient received a file merely because the share sheet opened or closed.

Web Share reference: https://www.w3.org/TR/web-share/

## Maternal assessment and pre-eclampsia

Saved maternal-risk results retain their original model, provenance, scores,
measurements and limitations. The same assessment displays a second PE review
step when the maternal category is MEDIUM or HIGH. It offers a doctor review
with the linked record preselected; the patient still reviews the appointment
and must consent before submitting. The doctor view does not show patient-only
booking actions. LOW is never presented as a negative PE diagnosis.

**Actual pre-eclampsia prediction is still not implemented.** This project has no
separate verified PE model or labelled PE training cohort. The existing maternal
model predicts UCI maternal-risk categories, not PE outcomes. No PE probability,
surrogate rule, synthetic label, chatbot prediction or fake result is added.
The assessment makes the unavailable prediction clear and provides the review
workflow instead. A PE model and suitable labelled data are still required to
complete the requested prediction feature.

The maternal screening model has not undergone clinical validation. This remains
visible in concise assessment copy and in evaluation details. A professional
interface does not change the model's clinical status.

## Verification and remaining live checks

- Frontend lint passed.
- All 69 frontend tests passed, including grouped navigation, role guards,
  Urdu/RTL, video access filtering, native report file handoff, desktop WhatsApp
  fallback, consent, cancellation, denied downloads and MEDIUM/HIGH/LOW PE states.
- Production build passed. No frontend dependency was added.
- Backend code and schema are unchanged by this patch.

Rendered desktop/mobile screenshots could not be verified in this environment:
the browser could not access the local preview, and local-file browsing was
blocked. Before final delivery, inspect the interface on the user's Windows
browser at desktop and phone widths, and test the real device's WhatsApp handoff.
Component tests use fixtures; no fixture API, review-only entry point, fictitious
account, screenshot harness or mock response is included in the update ZIP.
