# BloomCare session fix v0.2.2

This small update applies to the independent BloomCare v0.2.1 assessment project.
It adds no code, configuration, dataset, or model from the old project.

## What your backend log shows

Startup, registration, sign-in, and saving a health record succeeded. An initial
GET /api/auth/me returning 401 before sign-in is expected. Subsequent protected
requests returned 401, then succeeded after another sign-in. That shows a
rejected session; the log alone cannot distinguish expiration from missing or
invalid cookies. The configured default session duration is 30 minutes from
sign-in, with no automatic token renewal.

The UI previously retained its signed-in state after these protected 401s.
This update returns to sign-in with a clear message. Successful sign-in clears
the message. Bad login credentials keep their own error, and a forbidden 403
or a late response from an abandoned page does not end a valid session.

Your log has no POST /api/patients/me/assessments, so it does not demonstrate
that an assessment ran. A successful capabilities response also does not
establish that pregnancy_model_ready is true.

## Apply and check in Command Prompt

Stop the backend and frontend terminals with Ctrl+C. Extract this ZIP directly
into D:\Desktop\BloomCare and allow the included source files to replace their
v0.2.1 versions. Keep your existing configuration, database, trained model, and
virtual environment. No package installation or migration is needed for this fix.

    cd /d D:\Desktop\BloomCare
    npm.cmd --prefix .\frontend run lint
    npm.cmd --prefix .\frontend test
    npm.cmd --prefix .\frontend run build
    .\scripts\check-research-status.cmd

The status command is read-only: it reads the configuration used by a newly
started backend and verifies the registered artifact when research is enabled.
It prints no credentials or patient data. It does not query the running server
or change the database. Exit code 0 means the configured model is ready; 1 means
it is disabled, unavailable, or the check failed. PE is always unavailable at
this checkpoint.

If pregnancy_model_ready is true, start the backend and frontend as usual:

    .\scripts\start-backend.cmd

In another Command Prompt terminal:

    cd /d D:\Desktop\BloomCare
    .\scripts\start-frontend.cmd

Open http://127.0.0.1:5173 consistently, then sign in. Changing between localhost
and 127.0.0.1 changes the browser cookie host and can require a separate sign-in.

## If research is disabled

If research_enabled is false, and both model_files_present and
registration_present are true, the existing assessment checkpoint has a locally
trained and registered artifact but its configuration flag is disabled. Re-enable
it using the existing verifier, then check and restart the backend:

    .\backend\.venv\Scripts\python.exe .\scripts\enable_research_assessment.py --enable
    .\scripts\check-research-status.cmd

Do not manually set flags or bypass artifact verification. If registration is
missing or verification fails, finish the v0.2.1 update checkpoint instead:

    .\scripts\update-assessment.cmd

That existing command checks dependencies, tests, migration state, and the local
artifact before activation. Read the first failure if it stops.

## Run and confirm an assessment

1. Sign in, open History, and choose View experimental assessment for a record.
2. Click Run experimental assessment when enabled. The backend should log
   POST /api/patients/me/assessments with 200 OK, and the page should show a
   stored model result and SHAP explanation.
3. Open Assessments and reload to confirm the result is persisted.

An out-of-coverage record returns 422 and remains saved without a generated
assessment. For example, this model's training glucose starts at 6 mmol/L.
Keep actual measurements unchanged. For an FYP demonstration, the already
included docs/PUBLIC-DEMO-0.2.1.json contains labelled public-source examples
for a separate test account.

This fix does not change model performance, research limitations, or the PE
gate. PE remains unavailable. Validation: 16 frontend tests, frontend lint and
production build, Python lint, and local read-only readiness checks. Windows
CMD wrappers were inspected; native Windows execution is performed on your PC.
