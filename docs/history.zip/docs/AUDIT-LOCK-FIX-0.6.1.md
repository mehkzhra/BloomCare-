# PostgreSQL audit lock fix v0.6.1

Your diagnostic log confirms all 118 previous tests passed on the direct
SQLite test run. That run does not verify live PostgreSQL locks.

The original PostgreSQL path contains a blocking cycle: the request can hold
SELECT FOR UPDATE on a user row until its request-scoped session closes after
response delivery. Response middleware tries to insert a separate audit row
whose actor foreign key needs a conflicting lock on that same user row. Audit
is waiting for request cleanup while response delivery waits for audit.
The upload error and assistant retry paths can retain such request locks.

This patch removes the audit actor foreign key while keeping its actor ID,
which is set from server-side authentication. All care/ownership foreign keys
and role checks remain. Audit insertion runs in a worker thread rather than
blocking the event loop, with bounded PostgreSQL lock/statement waits. Audit
history remains readable for a former/deleted account. Migration 0008 preserves
all audit IDs and rows and leaves patient/doctor records intact.

References for the lifecycle and locking behavior:
https://fastapi.tiangolo.com/advanced/advanced-dependencies/
https://www.postgresql.org/docs/17/explicit-locking.html

## Apply

Stop both application servers and let any current diagnostic test finish.
Extract directly into D:\Desktop\BloomCare, replacing included files.
Keep Docker Desktop running. In Command Prompt:

    cd /d D:\Desktop\BloomCare
    .\scripts\update-remaining.cmd

The existing installer now uses the updated test_postgres.py. It prints each
test name and stops at the first failure. Test-only SQL lock/statement timeouts
and a 45-second stack dump expose any long wait; each subprocess is bounded
at 15 minutes. The uniquely named temporary test database is removed after
completion. No checks are skipped. Development migration runs only after
PostgreSQL, frontend and dependency checks pass.

Expected: 120 PostgreSQL tests pass, followed by 50 UI tests/build, migration
0008_audit_lock_fix and the existing final message:

    Remaining workflows update passed. Restart the backend and frontend.

If it stops, share the first error and the last printed test name. No package
reinstall, model retraining, setup reset or database deletion is needed.

## Verification

119 tests passed on SQLite; the actual PostgreSQL row-lock test was skipped
because a live server is unavailable here. That test keeps a user row locked
while a separate audit transaction commits, with a short lock timeout so it
cannot silently hang. It runs on PostgreSQL in your installer.
SQLite migration upgrade/downgrade/reapply, preserved audit actor/history,
previous medication preservation and schema comparison passed. PostgreSQL
migration SQL compiled. Python lint passed. Frontend files were not changed.
Native Windows and live PostgreSQL remain local verification steps.
