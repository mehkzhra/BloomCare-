# SRS delivery addendum - BloomCare v0.9.0

Date: 16 October 2026. This addendum maps the delivered source to the user's
`BloomCare_SRS(1).pdf`. The original supplied PDF is unchanged. Requirement IDs
below follow the SRS; the older SDD numbering diverges after FR-05 and must not be
used to identify these requirements. This is a delivery traceability record, not
a claim of stakeholder sign-off or medical certification.

## Functional requirements

| SRS ID | Requirement | v0.9.0 implementation and boundary |
| --- | --- | --- |
| FR-01 | User authentication | Website patient/doctor registration, role-aware sign-in, hashed passwords, signed session cookie and logout. Admin is managed separately. |
| FR-02 | Role-based access | Backend patient/approved-doctor/admin checks; own-record access and selected, time-limited care grants. Admin account/activity oversight is role scoped. |
| FR-03 | Maternal assessment | One input form with core observations and optional known antenatal measurements. Defaults mg/dL/F; optional mmol/L/C conversions; physical record bounds and separate inference bounds. |
| FR-04 | Pregnancy risk prediction | Actual registered independently trained maternal Random Forest and stored model version/scores. No rule-based replacement; existing trained artifact is retained by this update. |
| FR-05 | Staged PE screening | MEDIUM/HIGH or SBP >=140, DBP >=90, history of hypertension, or recorded proteinuria opens PE. Supported complete inputs auto-run the pinned original forest. Missing inputs request completion; unsupported values are saved and routed to review. |
| FR-06 | Explainable AI output | Per-feature contributions, explained category, base and record model scores for both supported model stages. |
| FR-07 | AI care plan generation | Explicitly consented Groq generation using the selected assessment, measurements and actual PE state. Saved guide with provider/language/context provenance; no generated fallback on failure. Live key/provider access required. |
| FR-08 | Assessment storage | Immutable maternal observations/results; separately stored PE, clinical input snapshot, saved care-plan versions and review history in PostgreSQL. Record request UUID prevents duplicate retry saves. |
| FR-09 | Patient history | Own assessment/history views; accepted approved doctors see only selected records during active grants. Completed PE is consistent in history, timeline, passport and allowed family summary. |
| FR-10 | Appointment scheduling | Registered patients request approved doctors; consent and selected records; future-slot and collision checks. Includes patient rescheduling and clinician follow-up proposals. |
| FR-11 | Appointment status | Doctor acceptance/rejection/completion with state checks. Rescheduling returns to PENDING, ends old access/calls and removes old report shares. |
| FR-12 | Doctor notes | Approved, authorized clinician notes; optional assessment linkage; public/private visibility; author-owned append-only amendments retain originals. Public corrections remain patient visible. |
| FR-13 | Review status | Per-assessment PENDING/REVIEWED/URGENT_FOLLOW_UP, reason and optional follow-up time, optimistic version checks and immutable change events. |
| FR-14 | Urgent follow-up | Doctor-authored urgent review instructions, patient notification, admin oversight and optional follow-up appointment proposal. Patient acceptance does not silently confirm the appointment. |
| FR-15 | PDF reports | Local jsPDF, paginated observations and known clinical values, maternal/PE results, SHAP, saved guide/freshness, review and patient-visible notes. Embedded Latin/Urdu fonts; full report generation checked. |
| FR-16 | WhatsApp alerts | Twilio server integration with approved-recipient list, consent, request-id deduplication, rate limit and provider status retrieval. Requires configured sender/account/template/session; automated real delivery is not claimed from mocked tests. Device PDF sharing is a separate implemented workflow. |
| FR-17 | Analytics | Stored category counts and native SVG charts, role-scoped doctor cases/review progress, admin totals and actual patient measurement trends. Saved-review groups in admin analytics describe stored review rows. |
| FR-18 | Search/filter | Admin name/email/role/active filters; authorized doctor patient/assessment search; own history risk/review/date filters; pagination. Local date filters become UTC boundaries; invalid/naive/reversed intervals rejected. |
| FR-19 | Frontend protection | Authenticated role routes plus session-expiry handling; backend independently enforces the same authority. |
| FR-20 | Video consultation | Appointment-linked protected WebRTC signaling and doctor-start/patient-join UI; access window and end-call checks. Target-device media, HTTPS and cross-network TURN checks remain environmental acceptance work. |
| FR-21 | Medical report upload | Validated PDF/image uploads, own downloads and selected doctor shares; revocation and care-episode access. |
| FR-22 | AI maternal assistant | Separate consented Groq query feature, optional selected own-record context, English/Urdu answers, retry/history controls. Does not create screening predictions. |
| FR-23 | Pregnancy tracker | Saved due date or latest recorded gestational week plus elapsed days; trimester, planning milestones, guidance and recorded trends. No invented dates when source data is absent. |
| FR-24 | Medication reminders | Patient medication entries and one-time/12-hour/24-hour reminder choices; background deduplicated in-app notifications while the backend is running. No OS push or external medication delivery. |
| FR-25 | Symptom monitoring | Patient symptom entries, severity and historical timeline within own/authorized scope. |
| FR-26 | Digital health passport | Own consolidated summary, observations, medications, symptoms and recent full assessments/care plans. Authorized sharing remains explicit. |
| FR-27 | SHAP explainability | Actual TreeSHAP for maternal model and original PE forest/node weights; additive/model-parity verification and zero unused-feature contributions. |
| FR-28 | Notifications | Persisted in-app appointment/message/review/urgent/care-plan/follow-up/reminder notices, read state and assessment links. UI uses periodic polling; this is near-real-time delivery, not WebSocket or background OS push. |
| FR-29 | Multilingual support | English/Urdu selector and RTL; new clinical screens/consents/statuses/tracker labels translated. Urdu generated text and patient-visible notes retain Arabic shaping in PDF. User-entered content is not silently translated; PDF section labels are English. |
| FR-30 | Family portal | Account-bound invitations, explicit selected category consent, expiry and revocation. Read-only limited summaries; no private clinician notes or raw assessment observations in family assessment summaries. |
| FR-31 | Evaluation dashboard | Admin-protected registered maternal model metrics/provenance and verification information. Reported model scores/metrics remain visible as evidence, not clinical accuracy guarantees. |
| FR-32 | Deployment support | PostgreSQL config, migrations, environment management, startup/preflight, backups/guarded restore, cumulative Windows update and optional deployment templates. Actual hosted deployment/HTTPS/recovery/load validation remains unexecuted. |

## Business-rule clarifications

- SRS BR-07 specifies mg/dL only. v0.9.0 uses mg/dL by default and adds an explicit
  mmol/L choice, converting to the unchanged canonical backend/model unit. This
  is an intentional usability extension; it must be recorded as a variation.
- Model coverage hints are faint placeholders, not normal clinical ranges. The
  application permits real records outside model coverage within its record
  bounds and refuses unsupported inference. It does not clamp measurements.
- The PE warning gate and the original model's usable feature domain are
  different constraints. In particular, systolic >=140 triggers review/screening,
  while the legacy model supports only 90-130. It cannot generate a valid result
  for that warning value without a different validated model.
- SHAP weights were exported from the pinned original model. Web requests load
  checked JSON arrays; they do not deserialize the old pickle.
- Groq care guides and questions require distinct user actions/consent. Neither
  replaces a doctor's review, prescriptions or the deterministic model pipeline.
- External WhatsApp messages require explicit action, permitted recipients and
  provider configuration. QUEUED/SENT do not mean DELIVERED; UNCERTAIN does not
  cause an automatic second send. Opening a native share sheet is not proof of
  message delivery.

## Nonfunctional acceptance and remaining external work

| Area | Evidence or remaining acceptance work |
| --- | --- |
| Automated correctness | Backend 187 passed, 1 PostgreSQL-only test skipped in this Linux SQLite run. Frontend 95 passed. Populated migration and real-model/SHAP tests included. See release verification. |
| PostgreSQL destination | Windows updater runs the full migration/API suite in a disposable local PostgreSQL database before the application migration. This v0.9.0 suite has not yet been run on the user's Windows host. |
| Prediction quality | Current maternal held-out accuracy 71.11%, MEDIUM recall 33.33%. This does not meet an 85% target. PE's legacy 90.24% result has test/training overlap and cannot establish independent performance. |
| Performance and concurrency | Frontend production build verified. The SRS response-time/100-user targets were not load tested against a deployed PostgreSQL/provider stack. No invented benchmark is supplied. |
| Security/operations | Role/ownership/consent/revocation and secret-preservation tests pass. Production TLS/cookie settings, operational key management, provider configuration and recovery still require destination review. |
| Availability | Local startup and bounded failure/retry paths exist. No uptime, hosted availability or disaster-recovery guarantee was tested. |
| Browser/device acceptance | Component tests cover navigation, permission/error/consent paths and workflows. Actual camera/microphone, native sharing and mobile layout must be checked on target devices; live browser visual QA was unavailable here. |
| Clinical acceptance | Source-unit gaps, PE coverage and held-out evidence require qualified review and better independent data. Software integration does not remove these limitations. |

All requested functional module source is retained in the combined release.
Provider activation and the outstanding acceptance conditions above are explicit
handover items, rather than hidden claims of completed production validation.
