# Optional deployment templates

The normal CMD development start scripts remain the quickest local demonstration.
The following container template is included but was not built or deployed here.
It uses the existing Docker database/network, without copying or replacing data.

1. Finish update-remaining.cmd successfully and make a database backup.
2. Stop the native backend/frontend servers. Keep the existing database running:

       docker compose up -d --wait

3. Ensure backend/model-trust.json exists if assessments are enabled. The trained
   ml/artifacts folder and trust registry are mounted read-only.
4. Build/start the optional local release stack:

       docker compose -f compose.deploy.yaml up -d --build

5. Open http://127.0.0.1:8080 and test readiness:

       curl.exe --fail http://127.0.0.1:8080/api/health/ready

The deployment stack uses external network bloomcare-fresh_default created by
the original compose.yaml and connects to that database as db:5432. It exposes
only its web proxy on loopback port 8080. Both API and web images need internet
access for their first builds. The image excludes secrets, caches, backups and
local model files. Credentials are passed at runtime; models are read-only mounts.

For public hosting, choose a server/domain, install TLS at the public reverse
proxy, set COOKIE_SECURE=true in backend/.env and set ALLOWED_ORIGINS to the exact
HTTPS origin in compose.deploy.yaml. Keep PostgreSQL/API private, configure a
TURN service for remote video, and test persistence/restoration and access rules.
Do not expose the local HTTP template directly as a public clinical service.
No domain, TLS certificate or hosting account was configured in this update.

Stop only the release services with:

    docker compose -f compose.deploy.yaml down

Do not add --volumes to database teardown commands unless deliberately deleting
patient data. Native start scripts remain usable after stopping this stack.
