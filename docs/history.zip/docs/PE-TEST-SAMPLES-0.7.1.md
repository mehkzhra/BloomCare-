# Fictional PE workflow samples

These invented values exercise the software only. They are not example medical
targets, patient advice or a substitute for measurements. Create separate new
health records when trying changed PE inputs, because saved screening results
are immutable.

Use this health record for both examples:

| Measurement | Value |
| --- | --- |
| Age | 25 years |
| Pregnancy duration | 24 weeks |
| Systolic BP | 120 mmHg |
| Diastolic BP | 80 mmHg |
| Glucose | 9 mmol/L |
| Temperature | 37 °C |
| Heart rate | 80 beats/minute |

With the shipped maternal v0.2 model this gives **HIGH**, opening the PE stage.
The maternal and PE categories are different models and need not match.

| Additional PE input | Sample A | Sample B |
| --- | --- | --- |
| Number of pregnancies | 2 | 2 |
| Previous births | 1 | 1 |
| BMI | 24.5 | 35 |
| Diagnosed diabetes | No | Yes |
| Hypertension history | No | Yes |
| Haemoglobin (legacy HB value) | 10.5 | 8.5 |
| Estimated fetal weight | 1.2 kg | 1.2 kg |
| Protein in urine | No | Yes |
| Amniotic fluid measurement | 12 cm | 12 cm |
| Expected PE model category | LOW | MEDIUM |

No Doppler result is requested: the original trained forest never used those
empty columns. A LOW result does not exclude PE. The old HB column's unit is
undocumented; its scale must be confirmed before any clinical use.

Check saved history, repeat the same submit to confirm no duplicate is added,
and share the record with an accepted doctor appointment to review the stored
PE result. Use a pregnancy duration of 10 weeks in a separate fictional record
to check that PE correctly blocks unsupported saved measurements without
changing them or inventing a result.
