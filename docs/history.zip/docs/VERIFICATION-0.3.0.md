# Verification: appointment and review checkpoint v0.3.0

Verified on Python 3.12 and Node 24 with the existing pinned dependencies.
No old-project source, data, configuration, or model artifact was used.

## Application checks

- 84 backend tests passed, including the existing authentication, observation,
  actual-model, SHAP, PE-gate, activation, and ownership regressions.
- New checks cover explicit boolean consent, forged fields, future-time bounds,
  UTC normalization, record ownership, atomic booking, doctor approval and
  activation, participant isolation, pagination, and schema readiness.
- Two simultaneous patient requests for one doctor's slot produce exactly one
  appointment and event: one 201 response and one 409.
- Transition retries are idempotent. Terminal states cannot reopen. Cancellation,
  completion, expiry, and revoked approval deny review and new note writes.
- Actual stored model scores, explanations, and PE status are readable by the
  selected doctor only during the accepted episode and for the selected record.
  Stored assessments remain readable when new inference is disabled.
- Authorship is server-set; private notes are excluded from patient responses.
  Authored notes and patient-visible notes remain available after closure.
- 31 frontend tests passed, including the previous expired-session tests.
  They exercise booking/consent, UTC submission, conflict and decision errors,
  doctor acceptance, cancellation, records, note visibility, and clearing
  review content when access is revoked or expires, without a clock-skew loop.
- Frontend lint and production build passed. Frontend tests also passed with
  the process timezone set to Asia/Karachi.
- Python lint and pip dependency consistency passed.

The existing Starlette test-client deprecation warning remains. This update
does not change dependencies.

## Migration checks performed here

A temporary SQLite database was migrated to the previous assessment revision
and populated with test accounts, profiles, observations, model provenance,
and an actual independently trained-model result. The new migration was
applied, all new tables were populated, then it was downgraded and reapplied.

All previous rows were preserved exactly. Foreign-key checks were enabled for
the seeded database. Alembic schema comparison found no pending operations
after each upgrade. Both partial unique reservation indexes were verified.
PostgreSQL offline upgrade SQL compiled with the indexes and all new tables.

## Platform limits and local verification

Native Windows and a live PostgreSQL server are unavailable here. CMD wrappers
were inspected for CRLF endings, quoted paths, fail-fast behavior, directory
changes, and exit-code propagation.

The installer runs migration/schema checks and all backend tests against a
unique local PostgreSQL test database on the user's machine before upgrading
the development database. SQLite tests and compiled PostgreSQL SQL are not
reported as live PostgreSQL test results.

No public deployment, clinical validation, separate PE prediction, external
calendar, reminder, message, or video integration was tested or claimed.
