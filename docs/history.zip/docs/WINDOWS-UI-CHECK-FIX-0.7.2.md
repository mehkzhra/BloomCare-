# Finish the Windows PE update

The uploaded Windows log shows that all 170 PostgreSQL tests passed and the
temporary test database was removed. The first frontend run passed all 77 tests.
The second run failed while waiting for the patient dashboard after login.
The full updater stopped at that check, before its final application-database
migration step. A successful migration of the temporary test database does not
apply that migration to the application database.

This patch waits for the asynchronous login interaction to settle and verifies
the patient dashboard heading. Testing Library's async UI wait is five seconds,
the per-test limit is ten seconds, and Vitest runs up to two workers to reduce
concurrent jsdom resource use on Windows. The existing assertions still run.

Verification after this fix: all 77 frontend tests passed, with lint and the
production build. The generated application CSS/JavaScript bundle hashes match
v0.7.1. The finish command still needs to run on the user's Windows machine to
apply the application's pending database migration.

## Apply using CMD

Stop the frontend and backend. Extract this patch directly into
`D:\Desktop\BloomCare`, allowing replacement of the three frontend test/config
files, then run:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\finish-preeclampsia.cmd
```

This finish command is for the already-passed PostgreSQL run in the uploaded
log. It runs frontend lint, all frontend tests, the production build, PE model
integrity verification and database readiness. It then applies pending
migrations to the application's configured database, checks schema agreement
and prints the current migration. The expected head is `0009_pe_screening`.

For a fresh PE installation, use the existing full
`scripts\update-preeclampsia.cmd` instead. It also uses the corrected frontend
configuration and performs the complete PostgreSQL test run.

After the finish command succeeds, start the servers in separate CMD windows:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\start-backend.cmd
```

```bat
cd /d D:\Desktop\BloomCare
.\scripts\start-frontend.cmd
```

Refresh the browser with Ctrl+F5. Open a saved MEDIUM/HIGH maternal assessment
to complete the additional PE measurements.

The `StarletteDeprecationWarning` in the log accompanies a passing test run;
it is not the failing check reported here.

Configuration references:
- https://testing-library.com/docs/dom-testing-library/api-async/
- https://testing-library.com/docs/dom-testing-library/api-configuration/
- https://main.vitest.dev/config/maxworkers
