# Executed verification — BloomCare 1.0.1

17 October 2026. Tests ran on the actual release source in an isolated Linux environment with SQLite.

| Check | Result |
| --- | --- |
| Backend regression suite | **227 passed; 1 PostgreSQL-only locking test skipped** |
| Frontend component/integration suite | **122 passed; 0 failed** |
| ML contract and comparison tests | **11 passed; 0 failed** |
| Python Ruff and frontend ESLint | Passed |
| Production frontend build | Passed |
| Existing populated database upgrade | v0009 → head0011; original rows, foreign keys and Alembic model parity checked |
| Original PE forest | Integrity, column mapping and reference score parity passed |

New cases exercise owner-only deletion, other-role denial, idempotency, retained observations and notes, withdrawn pending proposals, blocked removed-result inference/exports/alerts, active dashboard/analytics filtering, family sharing, safe service diagnostics, direct/STUN/TURN/invalid modes, and Windows setup preserving existing settings without printing credentials. UI cases cover role privacy, Urdu, cancellation/failure, lazy deletion history and cleanup of camera tracks including a late permission response after cancellation.

The final removal query explicitly locks `FOR UPDATE OF assessments` for PostgreSQL: the eagerly loaded model-version outer join must not become a locking target. Removal checks were repeated after this dialect-specific refinement.

No new training, PDF renderer changes or production benchmark are claimed in v1.0.1. The actual v1.0.0 training reports, rendered-PDF verification and scoped synthetic benchmark remain available as historical evidence.

**Not executed here:** Windows/PostgreSQL release execution, browser visual QA, actual camera or microphone devices, two-device/TURN calls, live Groq/Twilio delivery, native sharing, HTTPS hosting, backup restoration, deployed load or independent clinical validation. The Windows updater runs the application’s PostgreSQL suite in a disposable local test database before its actual database upgrade. Device and provider checks are available in the updated UI for destination verification.

Machine-readable results: `VERIFICATION-1.0.1.json`.
