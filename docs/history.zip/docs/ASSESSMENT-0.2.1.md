# BloomCare assessment update v0.2.1

This update connects the model you trained in the NEW BloomCare project to
saved patient records. It adds experimental results, patient-specific SHAP
contributions, assessment history, source/model provenance, and admin evaluation.
It uses no source, model, or dataset copy from the old 17-module project.

## Apply the update in Command Prompt

Your terminal prompt is D:\Desktop\BloomCare>, which is Command Prompt.
Use the commands below. Set-Location and $LASTEXITCODE are PowerShell syntax.

1. Stop the backend and frontend terminals with Ctrl+C. Keep Docker Desktop running.
2. Extract this ZIP directly into D:\Desktop\BloomCare and allow file replacement.
   The backend, frontend, ml, scripts, and docs directories belong alongside the
   existing directories. This is an update for your current NEW project.
3. Run:

    cd /d D:\Desktop\BloomCare
    .\scripts\update-assessment.cmd

The script stops if a check fails. It installs the pinned SHAP dependencies,
verifies your local trained artifact, runs Python lint, 7 ML tests, the full
backend suite against a temporary PostgreSQL database, frontend lint and 11 UI
tests, and the production build. After those checks pass, it upgrades the
development database to 0002_research_assessments, checks the schema, verifies
SHAP, and enables research-only maternal assessments.

The PostgreSQL regression database has a unique bloomcare_test_* name and is
removed afterward. Your BloomCare development database is not dropped. The
migration adds model_versions and assessments; it preserves existing accounts,
profiles, and health records. The activation command preserves credentials and
the locally trained artifact while setting BLOOMCARE_RESEARCH_ASSESSMENTS=true
in backend/.env and creating backend/model-trust.json. Do not rerun setup.py.

Expected final message:

    Assessment update passed. Restart the backend and frontend using the start scripts.

## Start and check

In one Command Prompt terminal:

    cd /d D:\Desktop\BloomCare
    .\scripts\start-backend.cmd

In a second Command Prompt terminal:

    cd /d D:\Desktop\BloomCare
    .\scripts\start-frontend.cmd

In a third terminal, check readiness:

    curl.exe --fail http://127.0.0.1:8000/api/health/ready

Expected: {"status":"ready"}.
Open http://127.0.0.1:5173 in the browser. Both start scripts also work when
invoked from PowerShell, but the cd /d commands above are for Command Prompt.

## Check the patient workflow

1. Sign in as a patient.
2. Save measured observations in the labelled units.
3. Open History, choose View experimental assessment, then Run experimental assessment.
4. For supported inputs, review the actual dataset category, model class scores,
   SHAP contributions, PE-stage status, and saved timestamp.
5. Open Assessments and reload the page. The result should remain available.
   Repeating a request for the same record and model returns its saved result.
6. A second patient cannot read that record or result. Doctors cannot access
   arbitrary patient assessments; authorized care episodes are a later checkpoint.

Your existing 5.1 mmol/L glucose example can still be saved as a health record,
but it cannot be assessed by this model because the training data start at
6 mmol/L. The application rejects unsupported input without generating a
category or modifying the record. These are training-coverage bounds, not
normal clinical ranges. Do not change actual measurements to obtain a result.

For an FYP demonstration, use a clearly identified test patient account and
the public-source demo measurements in docs/PUBLIC-DEMO-0.2.1.json. The six
model measurements come from UCI. The 24-week field is an explicit demo value;
the source has no gestational-age feature, and that field is not used by the
model. The displayed category should be produced by the backend, not entered
by a client.

## PE stage and clinical limitations

The locked software gate is enforced by the backend and a database constraint:

| Maternal dataset category | PE required by software | Current PE status |
| --- | --- | --- |
| LOW | No | NOT_INDICATED; no PE stage is run |
| MEDIUM | Yes | UNAVAILABLE; the assessment is incomplete |
| HIGH | Yes | UNAVAILABLE; the assessment is incomplete |

A LOW result does not rule out pre-eclampsia. This is BloomCare's software rule,
not a universal clinical rule. No PE model, synthetic PE labels, clinical
probabilities, or diagnosis are supplied.

The actual held-out maternal-model accuracy remains 71.11%, macro F1 0.6671,
and MEDIUM recall 33.33%, from a single fixed grouped hold-out partition.
There is no external or clinical validation. Class scores are uncalibrated.
The interface visibly labels every result as research output.

The source training manifest remains unchanged. Application activation is
tracked separately by the local registration and environment flag. Model
version, original evaluation, dataset checksum, artifact checksum, feature
order, and units are preserved with each saved result's provenance.

## Verification performed here

- 45 backend tests and 7 ML tests passed on Python 3.12.
- All three real classifier outputs, SHAP reconstruction, private histories,
  PE gating, duplicate requests, unsupported inputs, disabled models, artifact
  tampering, unit changes, dependency mismatches, and activation were checked.
- 11 frontend tests, frontend lint, production build, Python lint, and dependency
  consistency passed.
- SQLite migrations matched the ORM schema; existing records survived upgrade
  and downgrade. PostgreSQL migration SQL compiled.
- Windows 64-bit Python 3.12 wheels were verified for all added dependencies.

A native Windows shell and a live PostgreSQL server were not available here.
The installer performs the new PostgreSQL migration and workflow checks on your
machine before updating the development database and enabling the model.
The existing httpx test-client deprecation warning does not fail these tests.

## Source and explanation method

Ahmed, M. (2020). Maternal Health Risk [Dataset]. UCI Machine Learning
Repository. https://doi.org/10.24432/C5DP5D, CC BY 4.0.
Original source: https://archive.ics.uci.edu/dataset/863/maternal+health+risk.
The included test CSV is this unchanged independently downloaded public source.
The application uses your locally trained model, not the model created by tests.

SHAP documentation:
https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html.
Tree-path-dependent SHAP is applied to the actual fitted Random Forest after
its preprocessing. Its base scores plus contributions are checked against every
class score. Contributions describe model behavior, not causal medical effects.

Load only your own locally generated artifact. A checksum detects a change
but does not establish that a third-party pickle/joblib file is safe.
Restart the backend after changing the artifact, registry, or research flag.

Appointments, authorized doctor care episodes, messaging, video, a separately
trained PE model, and the remaining platform modules are still pending.

