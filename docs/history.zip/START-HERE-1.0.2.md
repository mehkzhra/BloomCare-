# BloomCare 1.0.2 — patient information and health-record deletion

This combined Windows update includes all previous modules. It adds the missing **health-record** deletion flow and corrects the patient-facing technical evaluation shown in the reported screenshot.

## Install into the existing project

1. Stop backend and frontend servers.
2. Extract the ZIP directly into `D:\Desktop\BloomCare`, replacing included source files.
3. Keep Docker Desktop running and run:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

Wait for the v1.0.2 success message. This creates a database backup, tests the PostgreSQL upgrade in a disposable database, and applies additive migration `0012_health_record_removal`. Existing accounts, passwords, configuration, uploaded files, model trust and trained models are preserved. The ZIP excludes private runtime state.

Start backend and frontend in two separate CMD windows:

```bat
.\scripts\start-backend.cmd
```

```bat
.\scripts\start-frontend.cmd
```

Refresh the browser with **Ctrl+F5**. The footer must show **v1.0.2**. Open **Help & support → Application version → Check server version**. Both interface and server should report **1.0.2**. A mismatch means that the update or a server restart is incomplete. The reported screenshot showed the previous white-sidebar appearance; verify the version before concluding that a new feature is missing.

## What to check

| Page | Expected behavior |
| --- | --- |
| Patient assessment | Patient-oriented screening explanation. Technical held-out accuracy/recall/test-row metrics are absent from the patient page. The screening and medium-risk limitations remain explained plainly. |
| Admin → Model evaluation & evidence | Honest accuracy, recall and test information remain available. Training-data limitations are explained in their technical context. |
| Patient → Health record | **View health history** opens the saved record list. |
| Patient → Health history | **Delete health record** appears on each record. Confirm with a reason. |
| Saved assessment / measurements page | A health-record delete action also appears beside Saved measurements. Assessment-only deletion remains a separate choice. |
| Deletion log | Deleted health-record metadata loads only when opened. |
| Help & support | Interface/server version comparison starts only when requested. |

Deleting a health record withdraws its measurements **and linked assessments** from active care, selected-record sharing, charts, timeline, passport, family views and future assistant context. Existing clinical notes and a dated audit copy remain. Pending follow-up proposals tied to removed assessments are withdrawn. Previously sent files, messages and external copies cannot be recalled. Add a new record for corrected measurements.

See [docs/COMPLETE-DELIVERY-1.0.2.md](docs/COMPLETE-DELIVERY-1.0.2.md) for scope and verification limits.
