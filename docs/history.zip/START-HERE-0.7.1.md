# Apply the PE + professional interface update

For the existing `D:\Desktop\BloomCare` project with the working Groq integration.
The v0.7.0 interface is included in this ZIP.

1. Stop the frontend and backend.
2. Extract all folders directly into `D:\Desktop\BloomCare` and allow replacement.
3. Open Docker Desktop, then use **CMD**:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\update-preeclampsia.cmd
```

4. Restart with `scripts\start-backend.cmd` and, in a separate CMD window,
   `scripts\start-frontend.cmd`. Refresh using **Ctrl+F5**.
5. Open a MEDIUM/HIGH maternal assessment. Complete the additional PE form there.
   The doctor-review link, top video action, WhatsApp report option and separate
   chatbot assistant are available in the same interface.

This uses the old repository's fitted PE model. It provides a screening category,
not a confirmed diagnosis. Clinical validation is pending and source-data
limitations are disclosed in model information. Details: `docs\PE-ASSESSMENT-0.7.1.md`.
