# BloomCare v1.0.0

This combined update contains the redesigned patient, doctor and admin workspaces,
all earlier modules, workflow fixes and the executed model-training evidence.

Stop both servers. Extract directly into your existing `D:\Desktop\BloomCare`
folder and replace included source files. Keep Docker Desktop running. In CMD:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

After the success message, start `scripts\start-backend.cmd` and
`scripts\start-frontend.cmd` in separate CMD windows. Open http://127.0.0.1:5173
and press Ctrl+F5.

Existing accounts, passwords, configuration, records, uploads and the registered
maternal model are retained. The new training candidates did not meet all
improvement checks and are included as inactive evidence; they are not silently
substituted for the current model.

Read [the full handover guide](docs/COMPLETE-DELIVERY-1.0.0.md) and
[the recruiter walkthrough](docs/RECRUITER-WALKTHROUGH-1.0.0.md).
