@echo off
setlocal
pushd "%~dp0.."
if errorlevel 1 exit /b 1
set "BLOOMCARE_PYTHON=%CD%\backend\.venv\Scripts\python.exe"
if not exist "%BLOOMCARE_PYTHON%" (
    echo Complete the foundation and assessment setup before this update.
    goto failed
)
docker compose up -d --wait
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m pip check
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ruff check backend scripts --select I --fix --config backend\pyproject.toml
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ruff check backend scripts --config backend\pyproject.toml
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\test_postgres.py
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run lint
if errorlevel 1 goto failed
call npm.cmd --prefix frontend test
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run build
if errorlevel 1 goto failed

pushd backend
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m alembic upgrade head
if errorlevel 1 goto failed_backend
"%BLOOMCARE_PYTHON%" -m alembic check
if errorlevel 1 goto failed_backend
popd
echo Remaining workflows update passed. Restart the backend and frontend.
echo Existing accounts, records, model artifacts, and activation settings were preserved.
popd
endlocal
exit /b 0

:failed_backend
popd
:failed
echo Remaining workflows update stopped. Read the error above before continuing.
popd
endlocal
exit /b 1
