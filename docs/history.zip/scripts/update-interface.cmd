@echo off
setlocal
pushd "%~dp0.."
if errorlevel 1 exit /b 1
call npm.cmd --prefix frontend run lint
if errorlevel 1 goto failed
call npm.cmd --prefix frontend test
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run build
if errorlevel 1 goto failed
echo BloomCare colour and compact history update passed.
echo Restart the frontend, then refresh with Ctrl+F5.
echo No database migration or backend dependency change was needed.
popd
endlocal
exit /b 0
:failed
echo Interface update stopped. Read the error above before continuing.
popd
endlocal
exit /b 1
