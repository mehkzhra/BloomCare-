@echo off
setlocal
pushd "%~dp0.."
if errorlevel 1 exit /b 1
set "BLOOMCARE_PYTHON=%CD%\backend\.venv\Scripts\python.exe"
if not exist "%BLOOMCARE_PYTHON%" (
    echo Complete the existing backend setup first.
    goto failed
)
if not exist "backend\migrations\versions\0009_pe_screening.py" (
    echo Extract the PE assessment v0.7.1 update before running this finish step.
    goto failed
)
echo Finishing the PE update after the successful PostgreSQL test run.
call npm.cmd --prefix frontend run lint
if errorlevel 1 goto failed
call npm.cmd --prefix frontend test
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run build
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\verify_pe_model.py
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\prepare_backend.py
if errorlevel 1 goto failed
pushd backend
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m alembic upgrade head
if errorlevel 1 goto failed_backend
"%BLOOMCARE_PYTHON%" -m alembic check
if errorlevel 1 goto failed_backend
"%BLOOMCARE_PYTHON%" -m alembic current
if errorlevel 1 goto failed_backend
popd
echo PE update completed. The application database is ready.
echo Restart the backend and frontend, then refresh the browser with Ctrl+F5.
popd
endlocal
exit /b 0
:failed_backend
popd
:failed
echo PE finish step stopped. Read the error above before continuing.
popd
endlocal
exit /b 1
