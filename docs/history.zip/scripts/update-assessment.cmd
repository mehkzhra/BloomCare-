@echo off
setlocal
pushd "%~dp0.."
if errorlevel 1 exit /b 1
set "BLOOMCARE_PYTHON=%CD%\backend\.venv\Scripts\python.exe"
if not exist "%BLOOMCARE_PYTHON%" (
    echo Complete the foundation setup before applying this checkpoint.
    goto failed
)
if not exist "ml\artifacts\maternal_rf_v0.2\manifest.json" (
    echo Run ml\check-and-train.cmd before this assessment update.
    goto failed
)
"%BLOOMCARE_PYTHON%" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 'Python 3.12 is required.')"
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m pip install --only-binary=:all: -r backend\research-requirements.txt
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m pip check
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ml.verify_model
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ruff check backend scripts ml --config backend\pyproject.toml
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m pytest -c ml\pytest.ini ml\tests
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\test_postgres.py
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run lint
if errorlevel 1 goto failed
call npm.cmd --prefix frontend test
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run build
if errorlevel 1 goto failed

pushd backend
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m alembic upgrade head
if errorlevel 1 goto failed_backend
"%BLOOMCARE_PYTHON%" -m alembic check
if errorlevel 1 goto failed_backend
popd
"%BLOOMCARE_PYTHON%" scripts\enable_research_assessment.py --enable
if errorlevel 1 goto failed
echo Assessment update passed. Restart the backend and frontend using the start scripts.
popd
endlocal
exit /b 0

:failed_backend
popd
:failed
echo Assessment update stopped. Read the error above before continuing.
popd
endlocal
exit /b 1
