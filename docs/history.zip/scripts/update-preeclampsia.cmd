@echo off
setlocal
pushd "%~dp0.."
if errorlevel 1 exit /b 1
set "BLOOMCARE_PYTHON=%CD%\backend\.venv\Scripts\python.exe"
if not exist "%BLOOMCARE_PYTHON%" (
    echo Complete the existing BloomCare backend setup before this update.
    goto failed
)
"%BLOOMCARE_PYTHON%" -m pip check
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ruff check backend scripts --select I --fix --config backend\pyproject.toml
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m ruff check backend scripts --config backend\pyproject.toml
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\verify_pe_model.py
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\prepare_backend.py
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" scripts\test_postgres.py
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run lint
if errorlevel 1 goto failed
call npm.cmd --prefix frontend test
if errorlevel 1 goto failed
call npm.cmd --prefix frontend run build
if errorlevel 1 goto failed
pushd backend
if errorlevel 1 goto failed
"%BLOOMCARE_PYTHON%" -m alembic upgrade head
if errorlevel 1 goto failed_backend
"%BLOOMCARE_PYTHON%" -m alembic check
if errorlevel 1 goto failed_backend
popd
echo PE screening and interface update passed. Restart the backend and frontend.
echo Refresh the browser using Ctrl+F5. Open an assessment with MEDIUM or HIGH maternal risk.
popd
endlocal
exit /b 0
:failed_backend
popd
:failed
echo PE update stopped. Read the error above before continuing.
popd
endlocal
exit /b 1
