# BloomCare 1.0.1 — privacy, clarity and correction update

This is a combined source update for your existing Windows BloomCare installation. All previous modules and the v1.0.0 training evidence are included.

1. Stop your backend and frontend CMD windows.
2. Extract the ZIP into `D:\Desktop\BloomCare`, replacing project files.
3. In CMD, run:

```bat
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

The updater preserves local configuration, accounts, uploads and model trust, creates a database backup, tests an isolated PostgreSQL database and applies the additive `0011_assessment_removal` migration. Do not start the new backend against the old schema. If the updater stops, keep the first error and correct it before continuing.

Start these in two separate CMD windows, then refresh the browser with Ctrl+F5:

```bat
.\scripts\start-backend.cmd
```

```bat
.\scripts\start-frontend.cmd
```

## Your reported issues

| Issue | Change or next step |
| --- | --- |
| Same privacy page for everyone | Patient, doctor and administrator now have their own privacy responsibilities, actions and sidebar copy. |
| Mixed, weak colours | Navy shell; a single teal patient, blue doctor or violet admin accent; warning colours reserved for status. |
| Wrong assessment | Patient → Assessments → Delete assessment → enter reason → Confirm deletion. |
| PE outside model coverage | Exact recorded values and original model ranges are shown, with an explanation and a doctor-review action. |
| Video “Needs setup” | Correct direct/STUN/TURN configuration status; an on-demand camera/microphone check in Video consultation. |
| WhatsApp “Needs setup” | Manual PDF sharing remains available. Automatic alerts show missing setting names and the matching setup command. |

## Deleting a mistaken assessment

Deletion removes that result from active history, shared cases, family assessment views, timeline, passport and analytics. It blocks new assessment exports, care guides, PE runs and alerts for the result. Unaccepted follow-up proposals linked to it are withdrawn. Clinician notes remain marked with the removed-result label; a dated reason and original audit copy are retained. Repeating deletion is safe.

Saved **measurements remain in Health history**, and files/messages already sent outside the app cannot be recalled. For wrong measurements, add a **new, corrected health record**; the removed result cannot silently be regenerated. This feature is removal from active care, not permanent database erasure. The deletion log opens only on demand.

## Finish service setup

Open **Admin → Connected services** to see configuration details, missing names and copyable commands. A saved key or relay configuration is not a successful live check. Do not paste passwords or provider keys into chat or browser forms.

```bat
.\scripts\check-services.cmd
.\scripts\configure-whatsapp.cmd
.\scripts\configure-integrations.cmd webrtc
```

The video wizard offers direct, STUN, TURN or advanced JSON setup. Use your provider’s real TURN URLs and credentials for relay mode. Restart the backend after changes.

Automatic WhatsApp needs your Twilio account, sender, opted-in contacts and applicable sandbox/template setup. Manual PDF attachment uses the patient’s WhatsApp app. No provider account or credential is invented by this release.

See [docs/COMPLETE-DELIVERY-1.0.1.md](docs/COMPLETE-DELIVERY-1.0.1.md) for verification limits and the short handover checklist.
