# BloomCare v0.9.0

Extract this combined ZIP directly into your existing `D:\Desktop\BloomCare`
folder and replace the included source files. Stop both servers first and keep
Docker Desktop running. In CMD:

```cmd
cd /d D:\Desktop\BloomCare
.\scripts\update-final.cmd
```

When it prints `BloomCare v0.9.0 complete update passed`, run
`scripts\start-backend.cmd` and `scripts\start-frontend.cmd` in separate CMD
windows. Open http://127.0.0.1:5173 and press Ctrl+F5.

Do not rerun initial setup, delete database volumes, or replace your configuration
or trained maternal model. No passwords need to be taken from this ZIP.

Full instructions: [docs/COMPLETE-DELIVERY-0.9.0.md](docs/COMPLETE-DELIVERY-0.9.0.md).
